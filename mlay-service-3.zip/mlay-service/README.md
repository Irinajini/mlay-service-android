# M'lay Service

Application Android de livraison/transport fonctionnant **sans connexion internet**, avec une hiérarchie de secours automatique pour joindre un livreur : **Bluetooth d'abord, SMS ensuite**.

## Fonctionnement général

### Côté Client
1. Ouvre l'appli → "Je suis Client" → entre le numéro du livreur (utilisé seulement si le SMS de secours est nécessaire) → "Demander une course maintenant".
2. L'appli récupère automatiquement la position GPS.
3. **Étape 1 — Bluetooth (priorité, gratuit, pas besoin d'internet ni de SMS)** : l'appli cherche pendant quelques secondes un livreur "en service" à proximité (Bluetooth Low Energy) et lui envoie directement la position.
4. **Étape 2 — SMS (si aucun livreur trouvé en Bluetooth)** : un SMS est envoyé au numéro du livreur renseigné, avec les coordonnées GPS. Le format du message est personnalisable par l'admin (voir plus bas).

### Côté Livreur
1. Ouvre l'appli → "Je suis Livreur" → entre son nom → "Se mettre EN service".
2. Le téléphone devient détectable en Bluetooth par les clients à proximité, et reste à l'écoute des SMS `MLAY:...`.
3. Dès qu'une demande arrive (Bluetooth ou SMS), une notification apparaît. En appuyant dessus (ou sur "Ouvrir la dernière demande dans Maps"), l'appli lance directement **Google Maps** avec l'itinéraire vers le client.
4. À la première mise en service, un SMS unique est envoyé au numéro de l'admin renseigné, pour signaler l'inscription du livreur (nom + son numéro apparaît automatiquement comme expéditeur).

### Côté Admin
- Accessible depuis l'écran d'accueil, protégé par un code PIN (par défaut `1234`, à changer immédiatement).
- Permet de modifier le **modèle du SMS de secours** envoyé par les clients (garder `{lat}`, `{lon}`, `{time}` dans le texte pour que ça reste exploitable par le livreur).
- Permet de tenir un **carnet manuel** des livreurs connus (nom + numéro).
- Affiche le **journal des livreurs qui se sont inscrits** (déclenché automatiquement par le SMS envoyé lors de la première mise en service).
- Permet de changer le **code PIN** admin.

## Limites importantes à connaître

- **Pas de compte centralisé / synchronisation en temps réel** : chaque téléphone ne connaît que ses propres données. Il n'y a pas de serveur central (Firebase a été volontairement écarté pour simplifier). L'admin ne voit donc que ce qui lui a été signalé par SMS (nouvelles inscriptions de livreurs) — pas de tableau de bord en direct des courses en cours ou des livreurs actuellement en service ; ce suivi reste manuel de son côté.
- **Portée Bluetooth réaliste** : environ 10 à 50 mètres selon les téléphones. Utile en zone dense (marché, quartier), moins pertinent sur de longues distances — le SMS prend alors le relais automatiquement.
- **La navigation Google Maps elle-même nécessite internet** (ou une carte préalablement téléchargée dans l'appli Google Maps). Pour une navigation 100% hors-ligne côté livreur, active dans Google Maps : `Menu → Cartes hors connexion → Sélectionner une zone` (couvre Toliara en quelques clics, aucun développement nécessaire).

## Carte hors-ligne de Toliara intégrée à l'appli (optionnelle)

Un écran dédié affiche une carte 100% offline dans l'appli elle-même (indépendante de Google Maps), via la librairie OSMDroid. Comme le projet ne peut pas embarquer un vrai fichier cartographique téléchargé depuis internet, **c'est à toi de fournir ce fichier** :

1. Génère ou télécharge un fichier `.mbtiles` couvrant Toliara — par exemple avec l'outil gratuit **MOBAC** (Mobile Atlas Creator) sur ordinateur, ou en exportant depuis **QGIS**.
2. Renomme-le exactement `toliara.mbtiles`.
3. Une fois l'appli installée sur le téléphone, place ce fichier dans : `Android/data/com.mlay.service/files/toliara.mbtiles` (accessible via un gestionnaire de fichiers, ou en le copiant par câble USB/ordinateur).
4. Relance l'appli → bouton "Carte de Toliara (hors ligne)" sur l'écran d'accueil.

Sans ce fichier, l'écran affiche un message d'erreur explicite mais l'appli reste utilisable normalement pour le reste (Bluetooth/SMS/Maps).

## Taille approximative de l'APK

- Version debug (celle générée par le workflow GitHub) : environ **15-20 Mo**, à cause des librairies Google Play Services (localisation) et OSMDroid (carte).
- Une version "release" optimisée serait plus légère (environ 10-15 Mo).
- Le fichier `toliara.mbtiles` (carte offline) est séparé et n'est pas compté dans la taille de l'APK — sa taille dépend entièrement du niveau de détail choisi lors de sa génération.

## Compiler l'APK via GitHub Actions (sans installer Android Studio)

Deux méthodes possibles, au choix :

**A. Upload direct du fichier ZIP (le plus simple depuis un téléphone)**
1. Crée un dépôt GitHub vide.
2. "Add file → Create new file" → nomme-le `.github/workflows/build.yml` → colle le contenu du fichier `build-from-zip.yml` fourni séparément → Commit.
3. "Add file → Upload files" → glisse le fichier `mlay-service.zip` tel quel (pas besoin de le dézipper) → Commit.
4. Le build se lance automatiquement dans l'onglet **Actions**.

**B. Dézipper et pousser le contenu (méthode classique avec Git)**
```bash
cd mlay-service
git init
git add .
git commit -m "Premier commit - M'lay Service"
git branch -M main
git remote add origin https://github.com/TON_USER/mlay-service.git
git push -u origin main
```

Dans les deux cas : onglet **Actions** → build terminé (✔ vert) → section "Artifacts" → télécharge l'APK.

## Installer l'APK sur un téléphone Android

1. Transfère le fichier `.apk` sur le téléphone.
2. Autorise l'installation d'applications de sources inconnues si demandé.
3. Ouvre le fichier `.apk` et installe.
4. Accepte toutes les permissions au premier lancement (position GPS, SMS, Bluetooth) — elles sont indispensables au fonctionnement.
5. Si Google Play Protect bloque l'installation : Play Store → profil → Play Protect → paramètres → désactiver temporairement l'analyse, installer, puis réactiver.

## Prochaines évolutions possibles

- Passer à un backend (Firebase ou autre) pour un vrai suivi en temps réel des livreurs actifs et des courses côté admin.
- Ajouter un système d'accusé de réception (le livreur confirme "J'arrive").
- Gérer plusieurs livreurs à la fois avec répartition automatique.

## Nouveautés — relais mesh, messagerie, validation admin

- **Relais Bluetooth mesh** : en plus de la liaison directe client → livreur, tout appareil M'lay ouvert (Client en train d'envoyer, Livreur en service, Admin, ou Messagerie) rediffuse aux appareils qu'il croise les messages qu'il ne connaît pas encore (inscriptions, validations, messages, courses), avec un compteur de sauts (TTL) pour éviter les boucles. Un message peut ainsi atteindre sa cible sans connexion directe, via un ou plusieurs téléphones intermédiaires. Cela ne fonctionne que pendant qu'un écran compatible est ouvert au premier plan (pas de service en arrière-plan dans cette version).
- **Accès Admin déplacé** : il n'est plus sur l'écran d'accueil. Depuis "Je suis Livreur", un appui long sur le titre "Espace Livreur" ouvre l'invite du code PIN.
- **Inscription livreur avec validation** : un nouveau livreur qui se met "en service" envoie sa demande à l'admin par SMS (canal principal) et par relais mesh (repli). L'admin la voit dans son panneau ("Inscriptions en attente") et doit cliquer "Valider" — c'est seulement à ce moment que le livreur est diffusé à tous les appareils du mesh et peut apparaître comme contact dans la Messagerie.
- **Messagerie** : accessible depuis "Je suis Livreur", permet d'échanger des messages texte avec l'Admin ou avec un livreur déjà validé, via le relais mesh (et SMS en repli si le numéro du contact est connu).

### Limite connue
Tout ce système mesh ne fonctionne que quand une activité compatible est à l'écran (pas de service Android en arrière-plan). Si besoin d'une réception even quand l'appli est fermée/minimisée, il faudra ajouter un Foreground Service — dites-le si vous voulez qu'on l'ajoute.
