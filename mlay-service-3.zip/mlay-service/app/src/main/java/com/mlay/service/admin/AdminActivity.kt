package com.mlay.service.admin

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mlay.service.R
import com.mlay.service.util.MeshEnvelope
import com.mlay.service.util.MeshRelayManager
import com.mlay.service.util.PrefsHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AdminActivity : AppCompatActivity(), MeshRelayManager.Listener {

    private lateinit var pendingContainer: LinearLayout
    private lateinit var validatedText: TextView
    private var mesh: MeshRelayManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val editTemplate = findViewById<EditText>(R.id.editSmsTemplate)
        val editDrivers = findViewById<EditText>(R.id.editDriverList)
        val editPin = findViewById<EditText>(R.id.editNewPin)
        val textLog = findViewById<TextView>(R.id.textAdminLog)
        pendingContainer = findViewById(R.id.pendingDriversContainer)
        validatedText = findViewById(R.id.textValidatedDrivers)

        editTemplate.setText(PrefsHelper.getSmsTemplate(this))
        editDrivers.setText(PrefsHelper.getDriverListRaw(this))
        textLog.text = PrefsHelper.getRegisteredDriversLog(this).ifEmpty {
            "Aucun livreur inscrit pour le moment."
        }

        findViewById<Button>(R.id.btnSaveTemplate).setOnClickListener {
            val template = editTemplate.text.toString().trim()
            if (!template.contains("{lat}") || !template.contains("{lon}")) {
                Toast.makeText(
                    this,
                    "Le modèle doit contenir {lat} et {lon} pour rester exploitable",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            PrefsHelper.saveSmsTemplate(this, template)
            Toast.makeText(this, "Modèle SMS enregistré sur cet appareil", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnSaveDrivers).setOnClickListener {
            PrefsHelper.saveDriverListRaw(this, editDrivers.text.toString())
            Toast.makeText(this, "Liste des livreurs enregistrée", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnChangePin).setOnClickListener {
            val newPin = editPin.text.toString().trim()
            if (newPin.length in 4..8 && newPin.all { it.isDigit() }) {
                PrefsHelper.saveAdminPin(this, newPin)
                Toast.makeText(this, "Code PIN admin mis à jour", Toast.LENGTH_SHORT).show()
                editPin.setText("")
            } else {
                Toast.makeText(this, "Le PIN doit contenir entre 4 et 8 chiffres", Toast.LENGTH_SHORT).show()
            }
        }

        mesh = MeshRelayManager(this)
        mesh?.start(this)

        refreshPendingDrivers()
        refreshValidatedDrivers()
    }

    /** Reçoit les inscriptions de livreurs (SMS -> SmsReceiver, ou mesh -> ici) et les demandes de messagerie. */
    override fun onEnvelopeDelivered(envelope: MeshEnvelope) {
        if (envelope.target != MeshEnvelope.TARGET_ADMIN && envelope.target != MeshEnvelope.TARGET_ALL) return
        when (envelope.type) {
            MeshEnvelope.TYPE_DRIVER_REG -> {
                val parts = envelope.payload.split("|")
                if (parts.size >= 2) {
                    val timestamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())
                    PrefsHelper.addPendingDriver(this, parts[0], parts[1], parts.getOrElse(2) { "" }, timestamp)
                    runOnUiThread {
                        refreshPendingDrivers()
                        Toast.makeText(this, "Nouvelle inscription livreur : ${parts[1]}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            else -> { /* ignoré ici */ }
        }
    }

    private fun refreshPendingDrivers() {
        pendingContainer.removeAllViews()
        val pending = PrefsHelper.getPendingDrivers(this)
        if (pending.isEmpty()) {
            val empty = TextView(this)
            empty.text = "Aucune inscription en attente."
            pendingContainer.addView(empty)
            return
        }
        for (driver in pending) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, 8, 0, 8)

            val label = TextView(this)
            label.text = "${driver.optString("name")} (${driver.optString("timestamp")})"
            label.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

            val validateBtn = Button(this)
            validateBtn.text = "Valider"
            validateBtn.setOnClickListener {
                validateDriver(driver.optString("id"), driver.optString("name"), driver.optString("phone"))
            }

            row.addView(label)
            row.addView(validateBtn)
            pendingContainer.addView(row)
        }
    }

    private fun validateDriver(id: String, name: String, phone: String) {
        PrefsHelper.removePendingDriver(this, id)
        PrefsHelper.addValidatedDriver(this, id, name, phone)

        // Diffusion à tous les appareils du mesh : ils ajoutent ce livreur à leur liste connue.
        mesh?.send(
            type = MeshEnvelope.TYPE_DRIVER_VALIDATED,
            target = MeshEnvelope.TARGET_ALL,
            fromName = "Admin",
            payload = "$id|$name|$phone"
        )
        if (phone.isNotEmpty()) {
            com.mlay.service.util.SmsHelper.sendSms(phone, "MLAY: votre inscription en tant que livreur est validée.")
        }

        Toast.makeText(this, "$name validé et diffusé aux appareils à proximité", Toast.LENGTH_SHORT).show()
        refreshPendingDrivers()
        refreshValidatedDrivers()
    }

    private fun refreshValidatedDrivers() {
        val validated = PrefsHelper.getValidatedDrivers(this)
        validatedText.text = if (validated.isEmpty()) {
            "Aucun livreur validé pour le moment."
        } else {
            validated.joinToString("\n") { "• ${it.optString("name")}" }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPendingDrivers()
        refreshValidatedDrivers()
    }

    override fun onDestroy() {
        super.onDestroy()
        mesh?.stop()
    }
}
