package com.mlay.service

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mlay.service.util.MeshEnvelope
import com.mlay.service.util.MeshRelayManager
import com.mlay.service.util.PrefsHelper
import com.mlay.service.util.SmsHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Messagerie interne : chaque message est relayé via le mesh Bluetooth (de proche en
 * proche jusqu'au destinataire) et, si son numéro est connu, également envoyé par SMS
 * en repli. Les contacts sont l'Admin et les livreurs déjà validés par l'admin.
 */
class MessengerActivity : AppCompatActivity(), MeshRelayManager.Listener {

    private lateinit var contactsContainer: LinearLayout
    private lateinit var threadScroll: ScrollView
    private lateinit var threadContainer: LinearLayout
    private lateinit var editMessage: EditText
    private var mesh: MeshRelayManager? = null

    private var currentContactId: String = MeshEnvelope.TARGET_ADMIN
    private var currentContactName: String = "Admin"
    private var currentContactPhone: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(24, 24, 24, 24)

        val title = TextView(this)
        title.text = "Messagerie"
        title.textSize = 22f
        root.addView(title)

        contactsContainer = LinearLayout(this)
        contactsContainer.orientation = LinearLayout.HORIZONTAL
        root.addView(contactsContainer)

        threadContainer = LinearLayout(this)
        threadContainer.orientation = LinearLayout.VERTICAL
        threadScroll = ScrollView(this)
        threadScroll.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        )
        threadScroll.addView(threadContainer)
        root.addView(threadScroll)

        val inputRow = LinearLayout(this)
        inputRow.orientation = LinearLayout.HORIZONTAL
        editMessage = EditText(this)
        editMessage.hint = "Votre message"
        editMessage.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        val sendBtn = Button(this)
        sendBtn.text = "Envoyer"
        sendBtn.setOnClickListener { sendMessage() }
        inputRow.addView(editMessage)
        inputRow.addView(sendBtn)
        root.addView(inputRow)

        setContentView(root)

        mesh = MeshRelayManager(this)
        mesh?.start(this)

        refreshContacts()
        loadThread()
    }

    private fun refreshContacts() {
        contactsContainer.removeAllViews()

        val adminBtn = Button(this)
        adminBtn.text = "Admin"
        adminBtn.setOnClickListener { selectContact(MeshEnvelope.TARGET_ADMIN, "Admin", "") }
        contactsContainer.addView(adminBtn)

        for (driver in PrefsHelper.getValidatedDrivers(this)) {
            val btn = Button(this)
            btn.text = driver.optString("name")
            btn.setOnClickListener {
                selectContact(driver.optString("id"), driver.optString("name"), driver.optString("phone"))
            }
            contactsContainer.addView(btn)
        }
    }

    private fun selectContact(id: String, name: String, phone: String) {
        currentContactId = id
        currentContactName = name
        currentContactPhone = phone
        loadThread()
    }

    private fun sendMessage() {
        val text = editMessage.text.toString().trim()
        if (text.isEmpty()) return

        val myName = PrefsHelper.getDriverName(this).ifEmpty { "Moi" }
        val id = UUID.randomUUID().toString()
        val timestamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())

        PrefsHelper.addMessengerMessage(this, id, currentContactId, currentContactName, text, timestamp, mine = true)
        mesh?.send(
            type = MeshEnvelope.TYPE_CHAT,
            target = currentContactId,
            fromName = myName,
            payload = text
        )
        if (currentContactPhone.isNotEmpty()) {
            SmsHelper.sendSms(currentContactPhone, "MLAY-MSG de $myName: $text")
        }

        editMessage.setText("")
        loadThread()
    }

    override fun onEnvelopeDelivered(envelope: MeshEnvelope) {
        if (envelope.type != MeshEnvelope.TYPE_CHAT) return
        val myId = PrefsHelper.getDeviceId(this)
        val isAdminTarget = envelope.target == MeshEnvelope.TARGET_ADMIN
        if (envelope.target != myId && !isAdminTarget) return

        val contactId = if (isAdminTarget) MeshEnvelope.TARGET_ADMIN else envelope.fromId
        val id = envelope.id
        val timestamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(envelope.ts))
        PrefsHelper.addMessengerMessage(this, id, contactId, envelope.fromName, envelope.payload, timestamp, mine = false)

        runOnUiThread {
            Toast.makeText(this, "Nouveau message de ${envelope.fromName}", Toast.LENGTH_SHORT).show()
            if (contactId == currentContactId) loadThread()
        }
    }

    private fun loadThread() {
        threadContainer.removeAllViews()
        val messages = PrefsHelper.getMessengerMessages(this, currentContactId)
        if (messages.isEmpty()) {
            val empty = TextView(this)
            empty.text = "Aucun message avec $currentContactName pour le moment."
            threadContainer.addView(empty)
            return
        }
        for (msg in messages) {
            val line = TextView(this)
            val mine = msg.optBoolean("mine")
            val who = if (mine) "Moi" else msg.optString("contactName")
            line.text = "${msg.optString("timestamp")} — $who : ${msg.optString("text")}"
            threadContainer.addView(line)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mesh?.stop()
    }
}
