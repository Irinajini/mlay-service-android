package com.mlay.service

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.mlay.service.offlinemap.OfflineMapActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnClient).setOnClickListener {
            startActivity(Intent(this, RequesterActivity::class.java))
        }
        findViewById<Button>(R.id.btnLivreur).setOnClickListener {
            startActivity(Intent(this, DriverActivity::class.java))
        }
        findViewById<Button>(R.id.btnCarte).setOnClickListener {
            startActivity(Intent(this, OfflineMapActivity::class.java))
        }
    }
}
