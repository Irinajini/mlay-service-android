package com.mlay.service.util

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import org.json.JSONArray

/**
 * Relais Bluetooth "mesh" par inondation : chaque appareil M'lay à proximité
 * (client, livreur en service, ou admin) rediffuse aux autres appareils qu'il
 * croise les messages qu'il n'a pas encore vu, jusqu'à ce qu'ils atteignent leur
 * cible ou que le TTL tombe à zéro. Pas besoin de connexion directe entre
 * l'expéditeur et le destinataire final : les téléphones alentour font le pont.
 *
 * Fonctionne uniquement pendant qu'une activité compatible (Livreur en service,
 * Admin, Messagerie, ou une recherche Client) est ouverte au premier plan — il
 * n'y a pas de service en arrière-plan dans cette version.
 */
class MeshRelayManager(private val context: Context) {

    interface Listener {
        fun onEnvelopeDelivered(envelope: MeshEnvelope)
    }

    private var listener: Listener? = null
    private var gattServer: BluetoothGattServer? = null
    private var running = false
    private val handler = Handler(Looper.getMainLooper())
    private val relayIntervalMs = 15_000L

    private val myId: String get() = PrefsHelper.getDeviceId(context)

    @SuppressLint("MissingPermission")
    fun start(listener: Listener?) {
        this.listener = listener
        if (running) return
        running = true

        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = manager?.adapter
        if (adapter == null || !adapter.isEnabled) return

        gattServer = manager.openGattServer(context, gattServerCallback)
        val service = BluetoothGattService(BleConstants.SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val characteristic = BluetoothGattCharacteristic(
            BleConstants.MESH_CHARACTERISTIC_UUID,
            BluetoothGattCharacteristic.PROPERTY_WRITE,
            BluetoothGattCharacteristic.PERMISSION_WRITE
        )
        service.addCharacteristic(characteristic)
        gattServer?.addService(service)

        BleAdvertiser.startAdvertising(context)
        scheduleRelayLoop()
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        gattServer?.close()
        gattServer = null
        listener = null
    }

    /** Crée et met en file un nouveau message à propager sur le mesh, puis tente une diffusion immédiate. */
    fun send(type: String, target: String, fromName: String, payload: String) {
        val envelope = MeshEnvelope.create(type, target, myId, fromName, payload)
        PrefsHelper.markMeshIdSeen(context, envelope.id)
        PrefsHelper.addToMeshOutbox(context, envelope.toJson())
        relayNow()
    }

    private fun scheduleRelayLoop() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (!running) return
                relayNow()
                handler.postDelayed(this, relayIntervalMs)
            }
        }, 1500)
    }

    /** Cherche les appareils M'lay à portée pendant une courte fenêtre et leur pousse la boîte d'envoi. */
    @SuppressLint("MissingPermission")
    private fun relayNow() {
        val outbox = PrefsHelper.getMeshOutbox(context)
        if (outbox.length() == 0) return

        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) return
        val scanner = adapter.bluetoothLeScanner ?: return

        val found = mutableSetOf<String>()
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(BleConstants.SERVICE_UUID)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val addr = result.device.address
                if (found.add(addr)) {
                    pushOutboxTo(result.device)
                }
            }
        }

        try {
            scanner.startScan(listOf(filter), settings, callback)
        } catch (e: Exception) {
            return
        }
        handler.postDelayed({
            try {
                scanner.stopScan(callback)
            } catch (e: Exception) {
                // ignore
            }
        }, 4000)
    }

    @SuppressLint("MissingPermission")
    private fun pushOutboxTo(device: BluetoothDevice) {
        val outbox = PrefsHelper.getMeshOutbox(context)
        val items = (0 until outbox.length()).map { outbox.getJSONObject(it).toString() }
        if (items.isEmpty()) return

        var index = 0
        var gatt: BluetoothGatt? = null
        gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    g.requestMtu(247)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    g.close()
                }
            }

            override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
                g.discoverServices()
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                writeNext(g)
            }

            override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
                index++
                if (index < items.size) {
                    writeNext(g)
                } else {
                    g.disconnect()
                }
            }

            fun writeNext(g: BluetoothGatt) {
                val service = g.getService(BleConstants.SERVICE_UUID)
                val characteristic = service?.getCharacteristic(BleConstants.MESH_CHARACTERISTIC_UUID)
                if (characteristic == null || index >= items.size) {
                    g.disconnect()
                    return
                }
                characteristic.value = items[index].toByteArray(Charsets.UTF_8)
                g.writeCharacteristic(characteristic)
            }
        })
        // Timeout de sécurité pour ne pas garder la connexion ouverte indéfiniment.
        handler.postDelayed({
            try {
                gatt?.disconnect()
                gatt?.close()
            } catch (e: Exception) {
                // ignore
            }
        }, 8000)
    }

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        @SuppressLint("MissingPermission")
        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray
        ) {
            if (characteristic.uuid == BleConstants.MESH_CHARACTERISTIC_UUID) {
                val text = String(value, Charsets.UTF_8)
                handleIncoming(text)
            }
            if (responseNeeded) {
                gattServer?.sendResponse(device, requestId, android.bluetooth.BluetoothGatt.GATT_SUCCESS, offset, value)
            }
        }
    }

    private fun handleIncoming(raw: String) {
        val envelope = MeshEnvelope.fromJson(raw) ?: return
        if (PrefsHelper.hasSeenMeshId(context, envelope.id)) return
        PrefsHelper.markMeshIdSeen(context, envelope.id)

        // Le listener (écran actuellement ouvert : Livreur, Admin ou Messagerie) décide
        // lui-même s'il est concerné par la cible de l'enveloppe (ALL, ADMIN, ou son propre ID).
        listener?.onEnvelopeDelivered(envelope)

        envelope.ttl -= 1
        if (envelope.ttl > 0) {
            PrefsHelper.addToMeshOutbox(context, envelope.toJson())
            relayNow()
        }
    }
}
