package com.mlay.service.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object PrefsHelper {
    private const val PREFS_NAME = "mlay_prefs"

    private const val KEY_DRIVER_NUMBER = "driver_number"
    private const val KEY_REQUEST_HISTORY = "request_history"
    private const val KEY_RECEIVED_HISTORY = "received_history"

    private const val KEY_ADMIN_PIN = "admin_pin"
    private const val KEY_SMS_TEMPLATE = "sms_template"
    private const val KEY_DRIVER_LIST_RAW = "driver_list_raw"
    private const val KEY_REGISTERED_DRIVERS_LOG = "registered_drivers_log"

    private const val KEY_DRIVER_NAME = "driver_name"
    private const val KEY_ADMIN_NUMBER_FOR_DRIVER = "admin_number_for_driver"
    private const val KEY_DRIVER_HAS_REGISTERED = "driver_has_registered"

    private const val KEY_DEVICE_ID = "device_id"
    private const val KEY_MESH_OUTBOX = "mesh_outbox"
    private const val KEY_MESH_SEEN_IDS = "mesh_seen_ids"
    private const val KEY_PENDING_DRIVERS = "pending_drivers"
    private const val KEY_VALIDATED_DRIVERS = "validated_drivers"
    private const val KEY_MESSENGER_HISTORY = "messenger_history"

    private const val DEFAULT_PIN = "1234"
    private const val DEFAULT_TEMPLATE = "MLAY:{lat},{lon}:{time}"
    private const val MAX_SEEN_IDS = 300

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ---- Identité locale de l'appareil (utilisée par le relais mesh) ----
    fun getDeviceId(context: Context): String {
        val existing = prefs(context).getString(KEY_DEVICE_ID, null)
        if (existing != null) return existing
        val generated = UUID.randomUUID().toString()
        prefs(context).edit().putString(KEY_DEVICE_ID, generated).apply()
        return generated
    }

    // ---- Relais mesh : boîte d'envoi (messages encore à propager) ----
    fun getMeshOutbox(context: Context): JSONArray =
        JSONArray(prefs(context).getString(KEY_MESH_OUTBOX, "[]"))

    fun saveMeshOutbox(context: Context, array: JSONArray) {
        prefs(context).edit().putString(KEY_MESH_OUTBOX, array.toString()).apply()
    }

    fun addToMeshOutbox(context: Context, envelopeJson: String) {
        val array = getMeshOutbox(context)
        array.put(JSONObject(envelopeJson))
        saveMeshOutbox(context, pruneMeshOutbox(array))
    }

    /** Retire de la boîte d'envoi les messages trop vieux (2h) ou si elle dépasse 150 entrées. */
    private fun pruneMeshOutbox(array: JSONArray): JSONArray {
        val maxAgeMs = 2 * 60 * 60 * 1000L
        val now = System.currentTimeMillis()
        val kept = mutableListOf<JSONObject>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            if (now - obj.optLong("ts", now) < maxAgeMs) kept.add(obj)
        }
        val trimmedStart = if (kept.size > 150) kept.size - 150 else 0
        val out = JSONArray()
        for (i in trimmedStart until kept.size) out.put(kept[i])
        return out
    }

    // ---- Relais mesh : IDs déjà vus (anti-boucle / anti-doublon) ----
    fun hasSeenMeshId(context: Context, id: String): Boolean {
        val array = JSONArray(prefs(context).getString(KEY_MESH_SEEN_IDS, "[]"))
        for (i in 0 until array.length()) {
            if (array.getString(i) == id) return true
        }
        return false
    }

    fun markMeshIdSeen(context: Context, id: String) {
        val array = JSONArray(prefs(context).getString(KEY_MESH_SEEN_IDS, "[]"))
        array.put(id)
        val trimmed = if (array.length() > MAX_SEEN_IDS) {
            val start = array.length() - MAX_SEEN_IDS
            val out = JSONArray()
            for (i in start until array.length()) out.put(array.getString(i))
            out
        } else array
        prefs(context).edit().putString(KEY_MESH_SEEN_IDS, trimmed.toString()).apply()
    }

    // ---- Livreurs en attente de validation par l'admin ----
    fun addPendingDriver(context: Context, id: String, name: String, phone: String, timestamp: String) {
        val array = JSONArray(prefs(context).getString(KEY_PENDING_DRIVERS, "[]"))
        for (i in 0 until array.length()) {
            if (array.getJSONObject(i).optString("id") == id) return
        }
        val obj = JSONObject().apply {
            put("id", id); put("name", name); put("phone", phone); put("timestamp", timestamp)
        }
        array.put(obj)
        prefs(context).edit().putString(KEY_PENDING_DRIVERS, array.toString()).apply()
    }

    fun getPendingDrivers(context: Context): List<JSONObject> {
        val array = JSONArray(prefs(context).getString(KEY_PENDING_DRIVERS, "[]"))
        return (0 until array.length()).map { array.getJSONObject(it) }
    }

    fun removePendingDriver(context: Context, id: String) {
        val array = JSONArray(prefs(context).getString(KEY_PENDING_DRIVERS, "[]"))
        val out = JSONArray()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            if (obj.optString("id") != id) out.put(obj)
        }
        prefs(context).edit().putString(KEY_PENDING_DRIVERS, out.toString()).apply()
    }

    // ---- Livreurs validés par l'admin (connus de cet appareil) ----
    fun addValidatedDriver(context: Context, id: String, name: String, phone: String) {
        val array = JSONArray(prefs(context).getString(KEY_VALIDATED_DRIVERS, "[]"))
        for (i in 0 until array.length()) {
            if (array.getJSONObject(i).optString("id") == id) return
        }
        val obj = JSONObject().apply { put("id", id); put("name", name); put("phone", phone) }
        array.put(obj)
        prefs(context).edit().putString(KEY_VALIDATED_DRIVERS, array.toString()).apply()
    }

    fun getValidatedDrivers(context: Context): List<JSONObject> {
        val array = JSONArray(prefs(context).getString(KEY_VALIDATED_DRIVERS, "[]"))
        return (0 until array.length()).map { array.getJSONObject(it) }
    }

    fun isDriverValidated(context: Context, id: String): Boolean =
        getValidatedDrivers(context).any { it.optString("id") == id }

    // ---- Messagerie ----
    fun addMessengerMessage(
        context: Context, id: String, contactId: String, contactName: String,
        text: String, timestamp: String, mine: Boolean
    ) {
        val array = JSONArray(prefs(context).getString(KEY_MESSENGER_HISTORY, "[]"))
        for (i in 0 until array.length()) {
            if (array.getJSONObject(i).optString("id") == id) return
        }
        val obj = JSONObject().apply {
            put("id", id); put("contactId", contactId); put("contactName", contactName)
            put("text", text); put("timestamp", timestamp); put("mine", mine)
        }
        array.put(obj)
        prefs(context).edit().putString(KEY_MESSENGER_HISTORY, array.toString()).apply()
    }

    fun getMessengerMessages(context: Context, contactId: String): List<JSONObject> {
        val array = JSONArray(prefs(context).getString(KEY_MESSENGER_HISTORY, "[]"))
        return (0 until array.length()).map { array.getJSONObject(it) }
            .filter { it.optString("contactId") == contactId }
    }

    // ---- Client : numéro du livreur utilisé pour le SMS de secours ----
    fun saveDriverNumber(context: Context, number: String) {
        prefs(context).edit().putString(KEY_DRIVER_NUMBER, number).apply()
    }

    fun getDriverNumber(context: Context): String {
        return prefs(context).getString(KEY_DRIVER_NUMBER, "") ?: ""
    }

    // ---- Historique des demandes envoyées (côté client) ----
    fun addSentRequest(context: Context, lat: Double, lon: Double, timestamp: String) {
        val array = JSONArray(prefs(context).getString(KEY_REQUEST_HISTORY, "[]"))
        val obj = JSONObject().apply {
            put("lat", lat); put("lon", lon); put("timestamp", timestamp)
        }
        array.put(obj)
        prefs(context).edit().putString(KEY_REQUEST_HISTORY, array.toString()).apply()
    }

    fun getSentRequests(context: Context): List<JSONObject> {
        val array = JSONArray(prefs(context).getString(KEY_REQUEST_HISTORY, "[]"))
        return (0 until array.length()).map { array.getJSONObject(it) }
    }

    // ---- Historique des demandes reçues (côté livreur) ----
    fun addReceivedRequest(context: Context, lat: Double, lon: Double, timestamp: String, from: String) {
        val array = JSONArray(prefs(context).getString(KEY_RECEIVED_HISTORY, "[]"))
        val obj = JSONObject().apply {
            put("lat", lat); put("lon", lon); put("timestamp", timestamp); put("from", from)
        }
        array.put(obj)
        prefs(context).edit().putString(KEY_RECEIVED_HISTORY, array.toString()).apply()
    }

    fun getReceivedRequests(context: Context): List<JSONObject> {
        val array = JSONArray(prefs(context).getString(KEY_RECEIVED_HISTORY, "[]"))
        return (0 until array.length()).map { array.getJSONObject(it) }
    }

    // ---- Admin ----
    fun getAdminPin(context: Context): String =
        prefs(context).getString(KEY_ADMIN_PIN, DEFAULT_PIN) ?: DEFAULT_PIN

    fun saveAdminPin(context: Context, pin: String) {
        prefs(context).edit().putString(KEY_ADMIN_PIN, pin).apply()
    }

    fun getSmsTemplate(context: Context): String =
        prefs(context).getString(KEY_SMS_TEMPLATE, DEFAULT_TEMPLATE) ?: DEFAULT_TEMPLATE

    fun saveSmsTemplate(context: Context, template: String) {
        prefs(context).edit().putString(KEY_SMS_TEMPLATE, template).apply()
    }

    fun getDriverListRaw(context: Context): String =
        prefs(context).getString(KEY_DRIVER_LIST_RAW, "") ?: ""

    fun saveDriverListRaw(context: Context, text: String) {
        prefs(context).edit().putString(KEY_DRIVER_LIST_RAW, text).apply()
    }

    fun addRegisteredDriver(context: Context, name: String, from: String, timestamp: String) {
        val current = getRegisteredDriversLog(context)
        val line = "• $timestamp — $name ($from)\n"
        prefs(context).edit().putString(KEY_REGISTERED_DRIVERS_LOG, line + current).apply()
    }

    fun getRegisteredDriversLog(context: Context): String =
        prefs(context).getString(KEY_REGISTERED_DRIVERS_LOG, "") ?: ""

    // ---- Livreur : identité locale ----
    fun saveDriverName(context: Context, name: String) {
        prefs(context).edit().putString(KEY_DRIVER_NAME, name).apply()
    }

    fun getDriverName(context: Context): String =
        prefs(context).getString(KEY_DRIVER_NAME, "") ?: ""

    fun saveAdminNumberForDriver(context: Context, number: String) {
        prefs(context).edit().putString(KEY_ADMIN_NUMBER_FOR_DRIVER, number).apply()
    }

    fun getAdminNumberForDriver(context: Context): String =
        prefs(context).getString(KEY_ADMIN_NUMBER_FOR_DRIVER, "") ?: ""

    fun hasDriverRegistered(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DRIVER_HAS_REGISTERED, false)

    fun setDriverRegistered(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_DRIVER_HAS_REGISTERED, value).apply()
    }
}
