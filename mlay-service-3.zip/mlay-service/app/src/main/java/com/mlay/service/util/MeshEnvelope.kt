package com.mlay.service.util

import org.json.JSONObject
import java.util.UUID

/**
 * Message qui circule sur le relais Bluetooth mesh (inondation avec TTL).
 * Chaque appareil qui le reçoit le relaie à son tour aux appareils qu'il croise,
 * jusqu'à ce qu'il atteigne sa cible ou que le TTL tombe à zéro.
 */
data class MeshEnvelope(
    val id: String,
    val type: String,       // RIDE, DRIVER_REG, DRIVER_VALIDATED, CHAT
    val target: String,     // "ADMIN", "ALL", ou l'ID d'un appareil précis
    val fromId: String,
    val fromName: String,
    val payload: String,    // contenu spécifique au type, en texte simple
    var ttl: Int,
    val ts: Long
) {
    companion object {
        const val TYPE_RIDE = "RIDE"
        const val TYPE_DRIVER_REG = "DRIVER_REG"
        const val TYPE_DRIVER_VALIDATED = "DRIVER_VALIDATED"
        const val TYPE_CHAT = "CHAT"

        const val TARGET_ADMIN = "ADMIN"
        const val TARGET_ALL = "ALL"

        const val DEFAULT_TTL = 6

        fun create(type: String, target: String, fromId: String, fromName: String, payload: String): MeshEnvelope {
            return MeshEnvelope(
                id = UUID.randomUUID().toString(),
                type = type,
                target = target,
                fromId = fromId,
                fromName = fromName,
                payload = payload,
                ttl = DEFAULT_TTL,
                ts = System.currentTimeMillis()
            )
        }

        fun fromJson(text: String): MeshEnvelope? {
            return try {
                val o = JSONObject(text)
                MeshEnvelope(
                    id = o.getString("id"),
                    type = o.getString("type"),
                    target = o.getString("target"),
                    fromId = o.optString("fromId"),
                    fromName = o.optString("fromName"),
                    payload = o.optString("payload"),
                    ttl = o.optInt("ttl", DEFAULT_TTL),
                    ts = o.optLong("ts", System.currentTimeMillis())
                )
            } catch (e: Exception) {
                null
            }
        }
    }

    fun toJson(): String {
        val o = JSONObject()
        o.put("id", id); o.put("type", type); o.put("target", target)
        o.put("fromId", fromId); o.put("fromName", fromName); o.put("payload", payload)
        o.put("ttl", ttl); o.put("ts", ts)
        return o.toString()
    }

    /** Ce message me concerne-t-il directement (à afficher/traiter localement) ? */
    fun isForMe(myId: String, myRoles: Set<String>): Boolean {
        return target == TARGET_ALL || target == myId || myRoles.contains(target)
    }
}
