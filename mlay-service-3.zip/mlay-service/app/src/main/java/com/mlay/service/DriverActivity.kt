package com.mlay.service

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mlay.service.admin.AdminActivity
import com.mlay.service.util.BleAdvertiser
import com.mlay.service.util.BleGattServerManager
import com.mlay.service.util.MapsHelper
import com.mlay.service.util.MeshEnvelope
import com.mlay.service.util.MeshRelayManager
import com.mlay.service.util.NotificationHelper
import com.mlay.service.util.PrefsHelper
import com.mlay.service.util.SmsHelper

class DriverActivity : AppCompatActivity(), MeshRelayManager.Listener {

    private lateinit var textHistory: TextView
    private lateinit var editDriverName: EditText
    private lateinit var editAdminNumber: EditText
    private lateinit var btnToggleService: Button
    private lateinit var titleView: TextView

    private var onDuty = false
    private var gattServer: BleGattServerManager? = null
    private var mesh: MeshRelayManager? = null

    private fun neededPermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
            list.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        return list.toTypedArray()
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver)

        titleView = findViewById(R.id.textDriverTitle)
        textHistory = findViewById(R.id.textHistoryDriver)
        editDriverName = findViewById(R.id.editDriverName)
        editAdminNumber = findViewById(R.id.editAdminNumber)
        btnToggleService = findViewById(R.id.btnToggleService)

        editDriverName.setText(PrefsHelper.getDriverName(this))
        editAdminNumber.setText(PrefsHelper.getAdminNumberForDriver(this))

        requestNeededPermissions()

        // Accès Admin discret : appui long sur le titre de l'écran (pas visible en présentation).
        titleView.setOnLongClickListener {
            promptAdminPin()
            true
        }

        btnToggleService.setOnClickListener {
            val name = editDriverName.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(this, "Entrez votre nom avant de vous mettre en service", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            PrefsHelper.saveDriverName(this, name)
            PrefsHelper.saveAdminNumberForDriver(this, editAdminNumber.text.toString().trim())

            if (!onDuty) startDuty(name) else stopDuty()
        }

        findViewById<Button>(R.id.btnOpenMaps).setOnClickListener {
            val requests = PrefsHelper.getReceivedRequests(this)
            if (requests.isNotEmpty()) {
                val latest = requests.last()
                MapsHelper.openNavigation(this, latest.getDouble("lat"), latest.getDouble("lon"))
            } else {
                Toast.makeText(this, "Aucune demande reçue pour le moment", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnMessenger).setOnClickListener {
            startActivity(Intent(this, MessengerActivity::class.java))
        }
    }

    private fun promptAdminPin() {
        val input = EditText(this)
        input.hint = "Code PIN admin"
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD

        AlertDialog.Builder(this)
            .setTitle("Accès Admin")
            .setView(input)
            .setPositiveButton("Valider") { _, _ ->
                if (input.text.toString() == PrefsHelper.getAdminPin(this)) {
                    startActivity(Intent(this, AdminActivity::class.java))
                } else {
                    Toast.makeText(this, "Code incorrect", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun requestNeededPermissions() {
        val missing = neededPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startDuty(name: String) {
        onDuty = true
        btnToggleService.text = "Se mettre HORS service"

        BleAdvertiser.startAdvertising(this)
        gattServer = BleGattServerManager(this) { payload ->
            runOnUiThread { handleIncomingRequest(payload, "Bluetooth direct") }
        }
        gattServer?.start()

        mesh = MeshRelayManager(this)
        mesh?.start(this)

        if (!PrefsHelper.hasDriverRegistered(this)) {
            registerWithAdmin(name)
        }

        Toast.makeText(this, "Vous êtes en service", Toast.LENGTH_SHORT).show()
    }

    /** Envoie la demande d'inscription à l'admin (SMS = liaison principale, mesh = repli) et attend sa validation. */
    private fun registerWithAdmin(name: String) {
        val driverId = PrefsHelper.getDeviceId(this)
        val adminNumber = editAdminNumber.text.toString().trim()

        if (adminNumber.isNotEmpty()) {
            SmsHelper.sendSms(adminNumber, SmsHelper.buildRegistrationMessage(name))
        }
        mesh?.send(
            type = MeshEnvelope.TYPE_DRIVER_REG,
            target = MeshEnvelope.TARGET_ADMIN,
            fromName = name,
            payload = "$driverId|$name|"
        )
        PrefsHelper.setDriverRegistered(this, true)
        Toast.makeText(this, "Inscription envoyée à l'admin, en attente de validation", Toast.LENGTH_LONG).show()
    }

    private fun stopDuty() {
        onDuty = false
        btnToggleService.text = "Se mettre EN service"
        BleAdvertiser.stopAdvertising(this)
        gattServer?.stop()
        gattServer = null
        mesh?.stop()
        mesh = null
        Toast.makeText(this, "Vous êtes hors service", Toast.LENGTH_SHORT).show()
    }

    private fun handleIncomingRequest(payload: String, source: String) {
        val parsed = SmsHelper.parsePayload(payload) ?: return
        val (lat, lon, timestamp) = parsed
        val display = timestamp.ifEmpty { "maintenant" }
        PrefsHelper.addReceivedRequest(this, lat, lon, display, source)
        NotificationHelper.createChannel(this)
        NotificationHelper.showNewRequestNotification(this, lat, lon)
        refreshHistory()
    }

    override fun onEnvelopeDelivered(envelope: MeshEnvelope) {
        when (envelope.type) {
            MeshEnvelope.TYPE_RIDE -> {
                runOnUiThread { handleIncomingRequest(envelope.payload, "Relais Bluetooth") }
            }
            MeshEnvelope.TYPE_DRIVER_VALIDATED -> {
                val parts = envelope.payload.split("|")
                if (parts.size >= 2) {
                    PrefsHelper.addValidatedDriver(this, parts[0], parts[1], parts.getOrElse(2) { "" })
                }
            }
            else -> { /* pas concerné côté livreur */ }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHistory()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (onDuty) {
            BleAdvertiser.stopAdvertising(this)
            gattServer?.stop()
            mesh?.stop()
        }
    }

    private fun refreshHistory() {
        val requests = PrefsHelper.getReceivedRequests(this)
        val sb = StringBuilder()
        for (req in requests.asReversed()) {
            sb.append("• ${req.getString("timestamp")} via ${req.optString("from", "?")} — (${req.getDouble("lat")}, ${req.getDouble("lon")})\n")
        }
        textHistory.text = if (sb.isEmpty()) "En attente de demandes de course..." else sb.toString()
    }
}
