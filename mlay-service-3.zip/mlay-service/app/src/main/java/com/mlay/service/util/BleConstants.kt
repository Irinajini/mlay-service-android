package com.mlay.service.util

import java.util.UUID

object BleConstants {
    val SERVICE_UUID: UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
    val REQUEST_CHARACTERISTIC_UUID: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")

    /** Caractéristique utilisée par le relais mesh (inscriptions, validations, messagerie, courses relayées). */
    val MESH_CHARACTERISTIC_UUID: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
}
