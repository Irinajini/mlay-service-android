# M'lay Service

Application Android de livraison/transport connectée à Firebase (Authentication +
Realtime Database). Trois rôles : Client, Livreur, Admin.

## Rôles

- **Client** : crée une demande de course (nom, téléphone, service, position GPS).
  Si internet est disponible, la demande part directement dans Firebase. Sinon, un
  SMS de secours est envoyé au numéro de dispatch renseigné.
- **Livreur** : se met "en service" pour voir les demandes en attente en direct, les
  accepte, et l'appli ouvre directement Google Maps avec l'itinéraire.
- **Admin** : reconnu automatiquement par son adresse e-mail
  (`andriafalinomenjanahary@gmail.com`, définie dans `FirebaseRepository.kt`). Voit
  la liste des clients inscrits, des livreurs (avec leur statut en service ou non),
  et les 30 dernières demandes avec leur statut.

## Connexion Admin — comment ça marche

Il n'y a pas de bouton "Accès Admin" séparé : il suffit de taper l'adresse e-mail de
l'admin dans le champ e-mail de l'écran de connexion. L'appli détecte automatiquement
que c'est l'admin et adapte l'écran (pas de bouton d'inscription, pas de mot de passe
oublié — juste un mot de passe à définir une seule fois).

Au tout premier lancement, ce mot de passe est créé automatiquement. Ensuite, Firebase
garde la session ouverte sur l'appareil : l'admin n'a plus jamais besoin de le
retaper au quotidien, sauf s'il se déconnecte explicitement ou change de téléphone.

## Pourquoi pas de "lien magique" ou de "code par e-mail" ?

Techniquement possible, mais :
- Le système de lien par e-mail de Firebase (Email Link) a changé en profondeur après
  la fermeture de Firebase Dynamic Links (25 août 2025) : il faut maintenant déployer
  Firebase Hosting via un ordinateur (ligne de commande), ce qui n'est pas possible
  depuis un téléphone seul.
- Un vrai code numérique envoyé par e-mail sans mot de passe nécessiterait un petit
  serveur (Cloud Functions), avec la complexité et les prérequis que ça implique.

La solution retenue (mot de passe défini une seule fois + session Firebase qui reste
ouverte automatiquement) donne le même confort au quotidien, sans aucun de ces
prérequis, et reste réellement sécurisée.

## Configuration Firebase déjà en place

Le fichier `app/google-services.json` fourni dans ce projet est configuré sur le
projet Firebase existant (`m-lay-service`). Vérifie dans la Console Firebase que :

1. **Authentication → Sign-in method** : la méthode **E-mail/Mot de passe** est activée.
2. **Realtime Database** : une base existe (URL utilisée dans le code :
   `https://m-lay-service-default-rtdb.firebaseio.com` — à adapter dans
   `FirebaseRepository.kt` si ton URL réelle est différente, ce qui peut arriver
   selon la région choisie à la création).
3. **Realtime Database → Règles** : copie le contenu du fichier `database.rules.json`
   fourni ici dans l'onglet "Règles" de la Console Firebase, puis publie.

## Carte hors-ligne de Toliara (optionnelle)

Toujours disponible depuis l'écran Client et Livreur ("Carte de Toliara hors ligne").
Nécessite un fichier `toliara.mbtiles` à placer dans
`Android/data/com.mlay.service/files/toliara.mbtiles` sur le téléphone (voir les
échanges précédents pour le générer avec un outil comme MOBAC).

## Compiler l'APK via GitHub Actions

Même principe que précédemment :
1. Crée un dépôt GitHub → ajoute `.github/workflows/build.yml` (contenu du fichier
   `build-from-zip.yml` fourni séparément) → uploade `mlay-service.zip` tel quel.
2. Le build se lance automatiquement dans l'onglet **Actions**.
3. Télécharge l'APK dans les "Artifacts" une fois le build terminé.

## Limites connues

- Pas encore de connexion par téléphone (SMS OTP) : gardée pour une prochaine étape,
  car elle demande une configuration Firebase supplémentaire (Play Integrity, SHA
  de l'appli, éventuellement le plan payant Blaze).
- La liste des livreurs dans le tableau de bord Admin se met à jour au clic sur
  "Actualiser", pas en direct en continu (pour rester simple et léger).
- Le SMS de secours n'est utilisé que côté Client quand il n'y a pas internet ; il
  n'y a plus de relais Bluetooth (abandonné à ta demande).
