package com.mlay.service.util

import android.telephony.SmsManager

/** SMS de secours utilisé uniquement quand l'appareil n'a pas internet. */
object SmsHelper {

    fun buildMessage(nom: String, telephone: String, service: String, lat: Double, lon: Double): String {
        return "MLAY course: $nom ($telephone) - $service - GPS:$lat,$lon"
            .take(320)
    }

    fun sendSms(number: String, message: String) {
        val smsManager = SmsManager.getDefault()
        val parts = smsManager.divideMessage(message)
        smsManager.sendMultipartTextMessage(number, null, parts, null, null)
    }
}
