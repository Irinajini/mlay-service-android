package com.mlay.service.util

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue

/**
 * Accès centralisé à Firebase Authentication et Realtime Database.
 */
object FirebaseRepository {

    const val ADMIN_EMAIL = "andriafalinomenjanahary@gmail.com"
    private const val DATABASE_URL = "https://m-lay-service-default-rtdb.firebaseio.com"

    const val ROLE_CLIENT = "client"
    const val ROLE_DRIVER = "livreur"
    const val ROLE_ADMIN = "admin"

    fun isAdminEmail(email: String): Boolean =
        email.trim().equals(ADMIN_EMAIL, ignoreCase = true)

    fun auth(): FirebaseAuth = FirebaseAuth.getInstance()

    /**
     * URL explicite pour éviter les erreurs lorsque google-services.json
     * a été téléchargé avant la création de Realtime Database.
     */
    fun db(): FirebaseDatabase = FirebaseDatabase.getInstance(DATABASE_URL)

    fun currentUid(): String? = auth().currentUser?.uid
    fun currentEmail(): String? = auth().currentUser?.email
    fun isLoggedIn(): Boolean = auth().currentUser != null

    fun signOut() = auth().signOut()

    fun saveUserProfile(
        uid: String,
        email: String,
        requestedRole: String,
        onDone: (Boolean, String) -> Unit
    ) {
        val role = if (isAdminEmail(email)) ROLE_ADMIN else requestedRole

        val profile = mapOf(
            "uid" to uid,
            "email" to email.trim().lowercase(),
            "role" to role,
            "active" to true,
            "createdAt" to ServerValue.TIMESTAMP
        )

        db().reference.child("users").child(uid).setValue(profile)
            .addOnSuccessListener {
                if (role == ROLE_DRIVER) {
                    val driver = mapOf(
                        "uid" to uid,
                        "email" to email.trim().lowercase(),
                        "available" to false,
                        "active" to true,
                        "latitude" to 0.0,
                        "longitude" to 0.0,
                        "updatedAt" to ServerValue.TIMESTAMP
                    )
                    db().reference.child("drivers").child(uid).setValue(driver)
                        .addOnSuccessListener { onDone(true, role) }
                        .addOnFailureListener {
                            onDone(false, it.localizedMessage ?: "Fiche livreur non enregistrée.")
                        }
                } else {
                    onDone(true, role)
                }
            }
            .addOnFailureListener {
                onDone(false, it.localizedMessage ?: "Profil non enregistré dans Realtime Database.")
            }
    }

    fun loadRole(uid: String, onDone: (String?) -> Unit) {
        db().reference.child("users").child(uid).child("role").get()
            .addOnSuccessListener { onDone(it.getValue(String::class.java)) }
            .addOnFailureListener { onDone(null) }
    }
}
