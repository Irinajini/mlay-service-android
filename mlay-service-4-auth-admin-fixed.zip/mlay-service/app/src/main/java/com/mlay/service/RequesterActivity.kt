package com.mlay.service

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.database.ServerValue
import com.mlay.service.offlinemap.OfflineMapActivity
import com.mlay.service.util.ConnectivityHelper
import com.mlay.service.util.FirebaseRepository
import com.mlay.service.util.LocationHelper
import com.mlay.service.util.MapsHelper
import com.mlay.service.util.SmsHelper
import android.content.Intent

class RequesterActivity : AppCompatActivity() {

    private lateinit var editName: EditText
    private lateinit var editPhone: EditText
    private lateinit var editService: EditText
    private lateinit var editDetails: EditText
    private lateinit var editDispatchNumber: EditText
    private lateinit var textStatus: TextView
    private lateinit var textHistory: TextView

    private var lat: Double? = null
    private var lon: Double? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true) captureLocation()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_requester)

        editName = findViewById(R.id.editName)
        editPhone = findViewById(R.id.editPhone)
        editService = findViewById(R.id.editService)
        editDetails = findViewById(R.id.editDetails)
        editDispatchNumber = findViewById(R.id.editDispatchNumber)
        textStatus = findViewById(R.id.textStatus)
        textHistory = findViewById(R.id.textHistory)

        findViewById<Button>(R.id.btnCaptureGps).setOnClickListener { ensureLocationPermission() }
        findViewById<Button>(R.id.btnSend).setOnClickListener { sendRequest() }
        findViewById<Button>(R.id.btnCarte).setOnClickListener {
            startActivity(Intent(this, OfflineMapActivity::class.java))
        }
        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            FirebaseRepository.signOut()
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
        }

        refreshConnectionLabel()
        listenToMyRequests()
    }

    override fun onResume() {
        super.onResume()
        refreshConnectionLabel()
    }

    private fun ensureLocationPermission() {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) captureLocation()
        else permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
    }

    private fun captureLocation() {
        textStatus.text = "Recherche de votre position..."
        LocationHelper.getCurrentLocation(this, onResult = { latitude, longitude ->
            lat = latitude
            lon = longitude
            textStatus.text = "Position captée : %.5f, %.5f".format(latitude, longitude)
        }, onError = {
            textStatus.text = "Impossible d'obtenir la position GPS. Activez le GPS et réessayez."
        })
    }

    private fun sendRequest() {
        val nom = editName.text.toString().trim()
        val telephone = editPhone.text.toString().trim()
        val service = editService.text.toString().trim()
        val details = editDetails.text.toString().trim()
        val latitude = lat
        val longitude = lon

        if (nom.isEmpty() || telephone.isEmpty()) {
            Toast.makeText(this, "Entrez votre nom et votre numéro", Toast.LENGTH_SHORT).show()
            return
        }
        if (latitude == null || longitude == null) {
            Toast.makeText(this, "Captez d'abord votre position GPS", Toast.LENGTH_SHORT).show()
            return
        }

        if (ConnectivityHelper.isOnline(this)) {
            sendOnline(nom, telephone, service, details, latitude, longitude)
        } else {
            sendBySms(nom, telephone, service, latitude, longitude)
        }
    }

    private fun sendOnline(nom: String, telephone: String, service: String, details: String, lat: Double, lon: Double) {
        textStatus.text = "Envoi de la demande..."
        val uid = FirebaseRepository.currentUid() ?: return
        val ref = FirebaseRepository.db().reference.child("requests").push()
        val data = mapOf(
            "id" to ref.key,
            "clientId" to uid,
            "nom" to nom,
            "telephone" to telephone,
            "service" to service,
            "details" to details,
            "latitude" to lat,
            "longitude" to lon,
            "statut" to "EN_ATTENTE",
            "creeLe" to ServerValue.TIMESTAMP
        )
        ref.setValue(data)
            .addOnSuccessListener {
                textStatus.text = "Demande envoyée ✔ En attente d'un livreur..."
            }
            .addOnFailureListener {
                textStatus.text = "Erreur d'envoi : ${it.localizedMessage}. Essai par SMS..."
                sendBySms(nom, telephone, service, lat, lon)
            }
    }

    private fun sendBySms(nom: String, telephone: String, service: String, lat: Double, lon: Double) {
        val number = editDispatchNumber.text.toString().trim()
        if (number.isEmpty()) {
            textStatus.text = "Hors ligne : entrez un numéro de dispatch pour l'envoi par SMS."
            return
        }
        val permission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
        if (permission != PackageManager.PERMISSION_GRANTED) {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            return
        }
        val message = SmsHelper.buildMessage(nom, telephone, service, lat, lon)
        SmsHelper.sendSms(number, message)
        textStatus.text = "Hors ligne : demande envoyée par SMS à $number ✔"
    }

    private val smsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) sendRequest() else Toast.makeText(this, "Permission SMS refusée", Toast.LENGTH_SHORT).show()
    }

    private fun listenToMyRequests() {
        val uid = FirebaseRepository.currentUid() ?: return
        FirebaseRepository.db().reference.child("requests")
            .orderByChild("clientId").equalTo(uid)
            .get()
            .addOnSuccessListener { snapshot ->
                val sb = StringBuilder()
                snapshot.children.sortedByDescending { it.child("creeLe").getValue(Long::class.java) ?: 0L }
                    .take(10)
                    .forEach { child ->
                        val statut = child.child("statut").getValue(String::class.java) ?: "?"
                        val serviceVal = child.child("service").getValue(String::class.java) ?: ""
                        sb.append("• $serviceVal — $statut\n")
                    }
                textHistory.text = if (sb.isEmpty()) "Aucune demande pour le moment." else sb.toString()
            }
    }

    private fun refreshConnectionLabel() {
        textStatus.text = if (ConnectivityHelper.isOnline(this))
            "Connexion internet disponible" else "Hors ligne — le SMS sera utilisé"
    }
}
