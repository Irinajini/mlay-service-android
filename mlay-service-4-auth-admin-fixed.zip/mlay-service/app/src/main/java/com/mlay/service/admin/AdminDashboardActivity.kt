package com.mlay.service.admin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.mlay.service.AuthActivity
import com.mlay.service.R
import com.mlay.service.util.FirebaseRepository

class AdminDashboardActivity : AppCompatActivity() {

    private lateinit var listClients: LinearLayout
    private lateinit var listDrivers: LinearLayout
    private lateinit var listRequests: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)

        listClients = findViewById(R.id.listClients)
        listDrivers = findViewById(R.id.listDrivers)
        listRequests = findViewById(R.id.listRequests)

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { loadAll() }
        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            FirebaseRepository.signOut()
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
        }

        loadAll()
    }

    private fun loadAll() {
        loadClients()
        loadDrivers()
        loadRequests()
    }

    private fun loadClients() {
        FirebaseRepository.db().reference.child("users")
            .orderByChild("role").equalTo(FirebaseRepository.ROLE_CLIENT)
            .get()
            .addOnSuccessListener { renderUsers(it, listClients, "Aucun client inscrit.") }
    }

    private fun loadDrivers() {
        FirebaseRepository.db().reference.child("users")
            .orderByChild("role").equalTo(FirebaseRepository.ROLE_DRIVER)
            .get()
            .addOnSuccessListener { snapshot ->
                listDrivers.removeAllViews()
                if (!snapshot.exists()) {
                    addEmptyLine(listDrivers, "Aucun livreur inscrit.")
                    return@addOnSuccessListener
                }
                for (child in snapshot.children) {
                    val email = child.child("email").getValue(String::class.java) ?: "?"
                    val uid = child.child("uid").getValue(String::class.java) ?: continue

                    FirebaseRepository.db().reference.child("drivers").child(uid).get()
                        .addOnSuccessListener { driverSnap ->
                            val availableVal = driverSnap.child("available").getValue(Boolean::class.java) ?: false
                            val line = TextView(this)
                            line.text = "• $email — ${if (availableVal) "EN SERVICE" else "hors service"}"
                            listDrivers.addView(line)
                        }
                }
            }
    }

    private fun loadRequests() {
        FirebaseRepository.db().reference.child("requests")
            .get()
            .addOnSuccessListener { snapshot ->
                listRequests.removeAllViews()
                if (!snapshot.exists()) {
                    addEmptyLine(listRequests, "Aucune demande pour le moment.")
                    return@addOnSuccessListener
                }
                val sorted = snapshot.children.sortedByDescending {
                    it.child("creeLe").getValue(Long::class.java) ?: 0L
                }
                for (child in sorted.take(30)) {
                    val nom = child.child("nom").getValue(String::class.java) ?: ""
                    val service = child.child("service").getValue(String::class.java) ?: ""
                    val statut = child.child("statut").getValue(String::class.java) ?: "?"
                    val line = TextView(this)
                    line.text = "• $nom — $service — $statut"
                    listRequests.addView(line)
                }
            }
    }

    private fun renderUsers(snapshot: DataSnapshot, container: LinearLayout, emptyText: String) {
        container.removeAllViews()
        if (!snapshot.exists()) {
            addEmptyLine(container, emptyText)
            return
        }
        for (child in snapshot.children) {
            val email = child.child("email").getValue(String::class.java) ?: "?"
            val active = child.child("active").getValue(Boolean::class.java) ?: true
            val line = TextView(this)
            line.text = "• $email" + if (!active) " (désactivé)" else ""
            container.addView(line)
        }
    }

    private fun addEmptyLine(container: LinearLayout, text: String) {
        val line = TextView(this)
        line.text = text
        container.addView(line)
    }
}
