package com.mlay.service

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import com.mlay.service.offlinemap.OfflineMapActivity
import com.mlay.service.util.FirebaseRepository
import com.mlay.service.util.LocationHelper
import com.mlay.service.util.MapsHelper

class DriverActivity : AppCompatActivity() {

    private lateinit var btnToggleAvailable: Button
    private lateinit var textStatus: TextView
    private lateinit var listContainer: LinearLayout

    private var available = false
    private var listener: ValueEventListener? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver)

        btnToggleAvailable = findViewById(R.id.btnToggleAvailable)
        textStatus = findViewById(R.id.textStatus)
        listContainer = findViewById(R.id.listRequests)

        permissionLauncher.launch(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.SEND_SMS)
        )

        btnToggleAvailable.setOnClickListener { toggleAvailability() }

        findViewById<Button>(R.id.btnCarte).setOnClickListener {
            startActivity(Intent(this, OfflineMapActivity::class.java))
        }
        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            stopListening()
            FirebaseRepository.signOut()
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
        }

        loadCurrentAvailability()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopListening()
    }

    private fun loadCurrentAvailability() {
        val uid = FirebaseRepository.currentUid() ?: return
        FirebaseRepository.db().reference.child("drivers").child(uid).child("available").get()
            .addOnSuccessListener {
                available = it.getValue(Boolean::class.java) ?: false
                updateToggleButton()
                if (available) startListening()
            }
    }

    private fun toggleAvailability() {
        val uid = FirebaseRepository.currentUid() ?: return
        available = !available
        FirebaseRepository.db().reference.child("drivers").child(uid).child("available").setValue(available)
        updateToggleButton()

        if (available) {
            updateMyLocation()
            startListening()
        } else {
            stopListening()
        }
    }

    private fun updateToggleButton() {
        btnToggleAvailable.text = if (available) "Se mettre HORS service" else "Se mettre EN service"
        textStatus.text = if (available) "Vous êtes en service. Demandes en attente ci-dessous."
            else "Vous êtes hors service."
    }

    private fun updateMyLocation() {
        val uid = FirebaseRepository.currentUid() ?: return
        LocationHelper.getCurrentLocation(this, onResult = { lat, lon ->
            FirebaseRepository.db().reference.child("drivers").child(uid).apply {
                child("latitude").setValue(lat)
                child("longitude").setValue(lon)
                child("updatedAt").setValue(ServerValue.TIMESTAMP)
            }
        }, onError = { })
    }

    private fun startListening() {
        if (listener != null) return
        val ref = FirebaseRepository.db().reference.child("requests")
            .orderByChild("statut").equalTo("EN_ATTENTE")

        listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                renderRequests(snapshot)
            }
            override fun onCancelled(error: DatabaseError) { }
        }
        ref.addValueEventListener(listener!!)
    }

    private fun stopListening() {
        listener?.let {
            FirebaseRepository.db().reference.child("requests")
                .orderByChild("statut").equalTo("EN_ATTENTE")
                .removeEventListener(it)
        }
        listener = null
    }

    private fun renderRequests(snapshot: DataSnapshot) {
        listContainer.removeAllViews()
        if (!snapshot.exists()) {
            val empty = TextView(this)
            empty.text = "Aucune demande en attente pour le moment."
            listContainer.addView(empty)
            return
        }

        for (child in snapshot.children) {
            val id = child.key ?: continue
            val nom = child.child("nom").getValue(String::class.java) ?: ""
            val telephone = child.child("telephone").getValue(String::class.java) ?: ""
            val service = child.child("service").getValue(String::class.java) ?: ""
            val lat = child.child("latitude").getValue(Double::class.java) ?: continue
            val lon = child.child("longitude").getValue(Double::class.java) ?: continue

            val itemLayout = LinearLayout(this)
            itemLayout.orientation = LinearLayout.VERTICAL
            itemLayout.setPadding(0, 16, 0, 16)

            val info = TextView(this)
            info.text = "$nom ($telephone) — $service"
            itemLayout.addView(info)

            val btnAccept = Button(this)
            btnAccept.text = "Accepter et ouvrir Maps"
            btnAccept.setOnClickListener { acceptRequest(id, lat, lon) }
            itemLayout.addView(btnAccept)

            listContainer.addView(itemLayout)
        }
    }

    private fun acceptRequest(requestId: String, lat: Double, lon: Double) {
        val uid = FirebaseRepository.currentUid() ?: return
        FirebaseRepository.db().reference.child("requests").child(requestId).apply {
            child("statut").setValue("ACCEPTEE")
            child("driverId").setValue(uid)
        }.also {
            Toast.makeText(this, "Course acceptée", Toast.LENGTH_SHORT).show()
            MapsHelper.openNavigation(this, lat, lon)
        }
    }
}
