package com.mlay.service

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.mlay.service.admin.AdminDashboardActivity
import com.mlay.service.util.FirebaseRepository

class AuthActivity : AppCompatActivity() {

    private lateinit var editEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var btnPrimary: Button
    private lateinit var btnRegisterClient: Button
    private lateinit var btnRegisterDriver: Button
    private lateinit var btnForgotPassword: TextView
    private lateinit var textStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        editEmail = findViewById(R.id.editEmail)
        editPassword = findViewById(R.id.editPassword)
        btnPrimary = findViewById(R.id.btnPrimary)
        btnRegisterClient = findViewById(R.id.btnRegisterClient)
        btnRegisterDriver = findViewById(R.id.btnRegisterDriver)
        btnForgotPassword = findViewById(R.id.btnForgotPassword)
        textStatus = findViewById(R.id.textStatus)

        FirebaseRepository.auth().setLanguageCode("fr")

        editEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) = updateModeForEmail()
        })

        btnPrimary.setOnClickListener { login() }
        btnRegisterClient.setOnClickListener {
            val email = editEmail.text.toString().trim()
            register(if (FirebaseRepository.isAdminEmail(email)) FirebaseRepository.ROLE_ADMIN else FirebaseRepository.ROLE_CLIENT)
        }
        btnRegisterDriver.setOnClickListener { register(FirebaseRepository.ROLE_DRIVER) }
        btnForgotPassword.setOnClickListener { forgotPassword() }

        updateModeForEmail()
    }

    override fun onStart() {
        super.onStart()
        val user = FirebaseRepository.auth().currentUser ?: return
        setBusy(true)
        user.reload()
            .addOnSuccessListener { routeAfterLogin() }
            .addOnFailureListener {
                FirebaseRepository.signOut()
                setBusy(false)
                textStatus.text = "La session précédente n'est plus valide. Reconnectez-vous."
            }
    }

    private fun updateModeForEmail() {
        val isAdmin = FirebaseRepository.isAdminEmail(editEmail.text.toString())
        editPassword.visibility = View.VISIBLE
        btnForgotPassword.visibility = View.VISIBLE

        if (isAdmin) {
            btnPrimary.text = "SE CONNECTER ADMIN"
            btnRegisterClient.text = "CRÉER LE COMPTE ADMIN"
            btnRegisterClient.visibility = View.VISIBLE
            btnRegisterDriver.visibility = View.GONE
            textStatus.text = "Adresse administrateur reconnue."
        } else {
            btnPrimary.text = "SE CONNECTER"
            btnRegisterClient.text = "CRÉER UN COMPTE CLIENT"
            btnRegisterClient.visibility = View.VISIBLE
            btnRegisterDriver.visibility = View.VISIBLE
            if (textStatus.text == "Adresse administrateur reconnue.") textStatus.text = ""
        }
    }

    private fun credentialsOrNull(): Pair<String, String>? {
        val email = editEmail.text.toString().trim().lowercase()
        val password = editPassword.text.toString()

        editEmail.error = null
        editPassword.error = null

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editEmail.error = "Adresse e-mail invalide"
            editEmail.requestFocus()
            return null
        }
        if (password.length < 6) {
            editPassword.error = "6 caractères minimum"
            editPassword.requestFocus()
            return null
        }
        return email to password
    }

    private fun login() {
        val (email, password) = credentialsOrNull() ?: return
        setBusy(true)

        FirebaseRepository.auth().signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { ensureProfileThenRoute(email) }
            .addOnFailureListener {
                setBusy(false)
                textStatus.text = authMessage(it)
            }
    }

    private fun register(role: String) {
        val (email, password) = credentialsOrNull() ?: return
        setBusy(true)

        FirebaseRepository.auth().createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid
                if (uid.isNullOrBlank()) {
                    setBusy(false)
                    textStatus.text = "Compte créé, mais identifiant introuvable."
                    return@addOnSuccessListener
                }
                FirebaseRepository.saveUserProfile(uid, email, role) { success, message ->
                    runOnUiThread {
                        if (success) {
                            Toast.makeText(this, "Compte créé avec succès", Toast.LENGTH_SHORT).show()
                            routeAfterLogin()
                        } else {
                            setBusy(false)
                            textStatus.text = "Compte Auth créé, mais $message"
                        }
                    }
                }
            }
            .addOnFailureListener {
                setBusy(false)
                textStatus.text = if (it is FirebaseAuthUserCollisionException) {
                    "Cette adresse possède déjà un compte. Utilisez SE CONNECTER ou Mot de passe oublié."
                } else authMessage(it)
            }
    }

    /**
     * Si Authentication contient encore un compte mais que son profil Realtime
     * Database a été supprimé, l'application le répare sans forcer une nouvelle inscription.
     */
    private fun ensureProfileThenRoute(email: String) {
        val uid = FirebaseRepository.currentUid()
        if (uid == null) {
            setBusy(false)
            textStatus.text = "Utilisateur introuvable après connexion."
            return
        }

        if (FirebaseRepository.isAdminEmail(email)) {
            FirebaseRepository.saveUserProfile(uid, email, FirebaseRepository.ROLE_ADMIN) { success, message ->
                runOnUiThread {
                    if (success) routeAfterLogin()
                    else {
                        setBusy(false)
                        textStatus.text = message
                    }
                }
            }
            return
        }

        FirebaseRepository.loadRole(uid) { role ->
            runOnUiThread {
                when (role) {
                    FirebaseRepository.ROLE_CLIENT,
                    FirebaseRepository.ROLE_DRIVER -> routeAfterLogin()
                    else -> askRoleToRepairProfile(uid, email)
                }
            }
        }
    }

    private fun askRoleToRepairProfile(uid: String, email: String) {
        setBusy(false)
        AlertDialog.Builder(this)
            .setTitle("Profil à restaurer")
            .setMessage("Le compte existe dans Authentication, mais son profil a été supprimé. Choisissez son type.")
            .setPositiveButton("Client") { _, _ -> repairProfile(uid, email, FirebaseRepository.ROLE_CLIENT) }
            .setNegativeButton("Livreur") { _, _ -> repairProfile(uid, email, FirebaseRepository.ROLE_DRIVER) }
            .setNeutralButton("Annuler", null)
            .show()
    }

    private fun repairProfile(uid: String, email: String, role: String) {
        setBusy(true)
        FirebaseRepository.saveUserProfile(uid, email, role) { success, message ->
            runOnUiThread {
                if (success) routeAfterLogin()
                else {
                    setBusy(false)
                    textStatus.text = message
                }
            }
        }
    }

    private fun forgotPassword() {
        val email = editEmail.text.toString().trim().lowercase()
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editEmail.error = "Entrez une adresse e-mail valide"
            editEmail.requestFocus()
            return
        }

        textStatus.text = "Envoi du lien de réinitialisation..."
        btnForgotPassword.isEnabled = false

        FirebaseRepository.auth().sendPasswordResetEmail(email)
            .addOnSuccessListener {
                btnForgotPassword.isEnabled = true
                textStatus.text = "Lien envoyé à $email. Vérifiez aussi le dossier Spam/Indésirables."
                Toast.makeText(this, "E-mail de réinitialisation envoyé", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener {
                btnForgotPassword.isEnabled = true
                textStatus.text = authMessage(it)
            }
    }

    private fun routeAfterLogin() {
        val uid = FirebaseRepository.currentUid()
        val email = FirebaseRepository.currentEmail().orEmpty()
        if (uid == null) {
            setBusy(false)
            return
        }

        if (FirebaseRepository.isAdminEmail(email)) {
            setBusy(false)
            startActivity(Intent(this, AdminDashboardActivity::class.java))
            finish()
            return
        }

        FirebaseRepository.loadRole(uid) { role ->
            runOnUiThread {
                setBusy(false)
                when (role) {
                    FirebaseRepository.ROLE_DRIVER ->
                        startActivity(Intent(this, DriverActivity::class.java))
                    FirebaseRepository.ROLE_CLIENT ->
                        startActivity(Intent(this, RequesterActivity::class.java))
                    else -> {
                        textStatus.text = "Profil introuvable. Reconnectez-vous pour le restaurer."
                        return@runOnUiThread
                    }
                }
                finish()
            }
        }
    }

    private fun authMessage(error: Exception): String = when (error) {
        is FirebaseAuthInvalidUserException ->
            "Aucun compte ne correspond à cette adresse."
        is FirebaseAuthInvalidCredentialsException ->
            "Adresse e-mail ou mot de passe incorrect."
        is FirebaseAuthUserCollisionException ->
            "Cette adresse est déjà utilisée par un autre compte."
        is FirebaseAuthException -> when (error.errorCode) {
            "ERROR_USER_DISABLED" -> "Ce compte a été désactivé."
            "ERROR_TOO_MANY_REQUESTS" -> "Trop de tentatives. Réessayez plus tard."
            "ERROR_NETWORK_REQUEST_FAILED" -> "Connexion internet indisponible."
            else -> error.localizedMessage ?: "Erreur d'authentification."
        }
        else -> error.localizedMessage ?: "Une erreur est survenue."
    }

    private fun setBusy(busy: Boolean) {
        btnPrimary.isEnabled = !busy
        btnRegisterClient.isEnabled = !busy
        btnRegisterDriver.isEnabled = !busy
        if (busy) textStatus.text = "Traitement en cours..."
    }
}
