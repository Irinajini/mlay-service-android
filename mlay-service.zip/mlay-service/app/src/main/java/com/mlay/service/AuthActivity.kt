package com.mlay.service

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mlay.service.admin.AdminDashboardActivity
import com.mlay.service.util.FirebaseRepository

class AuthActivity : AppCompatActivity() {

    private lateinit var editEmail: EditText
    private lateinit var editPassword: EditText
    private lateinit var btnPrimary: Button
    private lateinit var btnRegisterClient: Button
    private lateinit var btnRegisterDriver: Button
    private lateinit var btnForgotPassword: TextView
    private lateinit var textStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        editEmail = findViewById(R.id.editEmail)
        editPassword = findViewById(R.id.editPassword)
        btnPrimary = findViewById(R.id.btnPrimary)
        btnRegisterClient = findViewById(R.id.btnRegisterClient)
        btnRegisterDriver = findViewById(R.id.btnRegisterDriver)
        btnForgotPassword = findViewById(R.id.btnForgotPassword)
        textStatus = findViewById(R.id.textStatus)

        editEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = updateModeForEmail()
        })

        btnPrimary.setOnClickListener { onPrimaryClicked() }
        btnRegisterClient.setOnClickListener { register(FirebaseRepository.ROLE_CLIENT) }
        btnRegisterDriver.setOnClickListener { register(FirebaseRepository.ROLE_DRIVER) }
        btnForgotPassword.setOnClickListener { forgotPassword() }

        updateModeForEmail()
    }

    override fun onStart() {
        super.onStart()
        // Firebase garde la session ouverte automatiquement : si déjà connecté,
        // on saute directement à l'écran approprié sans redemander quoi que ce soit.
        if (FirebaseRepository.isLoggedIn()) {
            routeAfterLogin()
        }
    }

    /** Adapte le formulaire selon que l'e-mail saisi est celui de l'admin ou non. */
    private fun updateModeForEmail() {
        val email = editEmail.text.toString().trim()
        val isAdmin = FirebaseRepository.isAdminEmail(email)

        if (isAdmin) {
            editPassword.visibility = View.GONE
            btnRegisterClient.visibility = View.GONE
            btnRegisterDriver.visibility = View.GONE
            btnForgotPassword.visibility = View.GONE
            btnPrimary.text = "Connexion Admin"
        } else {
            editPassword.visibility = View.VISIBLE
            btnRegisterClient.visibility = View.VISIBLE
            btnRegisterDriver.visibility = View.VISIBLE
            btnForgotPassword.visibility = View.VISIBLE
            btnPrimary.text = "Se connecter"
        }
    }

    private fun onPrimaryClicked() {
        val email = editEmail.text.toString().trim()
        if (FirebaseRepository.isAdminEmail(email)) {
            loginAdminFirstTimeOrExisting(email)
        } else {
            login(email)
        }
    }

    /**
     * Pour l'admin : on demande un mot de passe et on tente directement la connexion.
     * Si le compte n'existe pas encore (première fois), on le crée automatiquement
     * avec ce même mot de passe. Ensuite, comme la session reste ouverte automatiquement
     * sur l'appareil, il ne sera plus jamais redemandé au quotidien.
     */
    private fun loginAdminFirstTimeOrExisting(email: String) {
        val input = EditText(this)
        input.hint = "Mot de passe admin (6 caractères min.)"
        input.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Accès Admin")
            .setMessage("Si c'est ta première connexion, ce mot de passe sera créé automatiquement. Ensuite, tu ne le retaperas plus jamais sur cet appareil.")
            .setView(input)
            .setPositiveButton("Continuer") { _, _ ->
                val pwd = input.text.toString()
                if (pwd.length < 6) {
                    Toast.makeText(this, "6 caractères minimum", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                signInAdmin(email, pwd)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun createAdminAccount(email: String, password: String) {
        setBusy(true)
        FirebaseRepository.auth().createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid ?: return@addOnSuccessListener
                FirebaseRepository.saveUserProfile(uid, email, FirebaseRepository.ROLE_ADMIN) { _, _ ->
                    routeAfterLogin()
                }
            }
            .addOnFailureListener {
                setBusy(false)
                textStatus.text = it.localizedMessage ?: "Impossible de créer l'accès admin."
            }
    }

    private fun signInAdmin(email: String, password: String) {
        setBusy(true)
        FirebaseRepository.auth().signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { routeAfterLogin() }
            .addOnFailureListener { exception ->
                if (exception is com.google.firebase.auth.FirebaseAuthInvalidUserException) {
                    // Aucun compte admin n'existe encore : on le crée avec ce mot de passe.
                    createAdminAccount(email, password)
                } else {
                    setBusy(false)
                    textStatus.text = exception.localizedMessage ?: "Mot de passe admin incorrect."
                }
            }
    }

    private fun credentialsOrNull(): Pair<String, String>? {
        val email = editEmail.text.toString().trim()
        val password = editPassword.text.toString()

        if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editEmail.error = "Adresse e-mail invalide"
            return null
        }
        if (password.length < 6) {
            editPassword.error = "6 caractères minimum"
            return null
        }
        return email to password
    }

    private fun login(email: String) {
        val (mail, password) = credentialsOrNull() ?: return
        setBusy(true)
        FirebaseRepository.auth().signInWithEmailAndPassword(mail, password)
            .addOnSuccessListener { routeAfterLogin() }
            .addOnFailureListener {
                setBusy(false)
                textStatus.text = it.localizedMessage ?: "Connexion impossible."
            }
    }

    private fun register(role: String) {
        val (email, password) = credentialsOrNull() ?: return
        setBusy(true)
        FirebaseRepository.auth().createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid
                if (uid == null) {
                    setBusy(false)
                    textStatus.text = "Compte créé, mais identifiant introuvable."
                    return@addOnSuccessListener
                }
                FirebaseRepository.saveUserProfile(uid, email, role) { success, message ->
                    if (success) routeAfterLogin() else {
                        setBusy(false)
                        textStatus.text = "Compte créé, mais $message"
                    }
                }
            }
            .addOnFailureListener {
                setBusy(false)
                textStatus.text = it.localizedMessage ?: "Création du compte impossible."
            }
    }

    private fun forgotPassword() {
        val email = editEmail.text.toString().trim()
        if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editEmail.error = "Entrez votre e-mail pour recevoir le lien"
            return
        }
        FirebaseRepository.auth().sendPasswordResetEmail(email)
            .addOnSuccessListener {
                textStatus.text = "E-mail de réinitialisation envoyé à $email"
            }
            .addOnFailureListener {
                textStatus.text = it.localizedMessage ?: "Impossible d'envoyer l'e-mail."
            }
    }

    private fun routeAfterLogin() {
        val uid = FirebaseRepository.currentUid()
        val email = FirebaseRepository.currentEmail() ?: ""
        if (uid == null) {
            setBusy(false)
            return
        }
        if (FirebaseRepository.isAdminEmail(email)) {
            startActivity(Intent(this, AdminDashboardActivity::class.java))
            finish()
            return
        }
        FirebaseRepository.loadRole(uid) { role ->
            runOnUiThread {
                setBusy(false)
                when (role) {
                    FirebaseRepository.ROLE_DRIVER -> startActivity(Intent(this, DriverActivity::class.java))
                    FirebaseRepository.ROLE_CLIENT -> startActivity(Intent(this, RequesterActivity::class.java))
                    else -> {
                        textStatus.text = "Profil introuvable. Réinscrivez-vous."
                        return@runOnUiThread
                    }
                }
                finish()
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        btnPrimary.isEnabled = !busy
        btnRegisterClient.isEnabled = !busy
        btnRegisterDriver.isEnabled = !busy
        if (busy) textStatus.text = "Traitement en cours..."
    }
}
