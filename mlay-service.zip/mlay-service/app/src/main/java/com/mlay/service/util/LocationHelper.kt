package com.mlay.service.util

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.CurrentLocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

object LocationHelper {
    @SuppressLint("MissingPermission")
    fun getCurrentLocation(context: Context, onResult: (Double, Double) -> Unit, onError: () -> Unit) {
        val client = LocationServices.getFusedLocationProviderClient(context)
        val request = CurrentLocationRequest.Builder()
            .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
            .build()
        client.getCurrentLocation(request, null)
            .addOnSuccessListener { location ->
                if (location != null) {
                    onResult(location.latitude, location.longitude)
                } else {
                    onError()
                }
            }
            .addOnFailureListener { onError() }
    }
}
