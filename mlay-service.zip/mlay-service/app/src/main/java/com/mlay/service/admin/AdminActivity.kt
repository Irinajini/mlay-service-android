package com.mlay.service.admin

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mlay.service.R
import com.mlay.service.util.PrefsHelper

class AdminActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val editTemplate = findViewById<EditText>(R.id.editSmsTemplate)
        val editDrivers = findViewById<EditText>(R.id.editDriverList)
        val editPin = findViewById<EditText>(R.id.editNewPin)
        val textLog = findViewById<TextView>(R.id.textAdminLog)

        editTemplate.setText(PrefsHelper.getSmsTemplate(this))
        editDrivers.setText(PrefsHelper.getDriverListRaw(this))
        textLog.text = PrefsHelper.getRegisteredDriversLog(this).ifEmpty {
            "Aucun livreur inscrit pour le moment."
        }

        findViewById<Button>(R.id.btnSaveTemplate).setOnClickListener {
            val template = editTemplate.text.toString().trim()
            if (!template.contains("{lat}") || !template.contains("{lon}")) {
                Toast.makeText(
                    this,
                    "Le modèle doit contenir {lat} et {lon} pour rester exploitable",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            PrefsHelper.saveSmsTemplate(this, template)
            Toast.makeText(this, "Modèle SMS enregistré sur cet appareil", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnSaveDrivers).setOnClickListener {
            PrefsHelper.saveDriverListRaw(this, editDrivers.text.toString())
            Toast.makeText(this, "Liste des livreurs enregistrée", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnChangePin).setOnClickListener {
            val newPin = editPin.text.toString().trim()
            if (newPin.length in 4..8 && newPin.all { it.isDigit() }) {
                PrefsHelper.saveAdminPin(this, newPin)
                Toast.makeText(this, "Code PIN admin mis à jour", Toast.LENGTH_SHORT).show()
                editPin.setText("")
            } else {
                Toast.makeText(this, "Le PIN doit contenir entre 4 et 8 chiffres", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
