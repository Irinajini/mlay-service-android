package com.mlay.service.util

import android.telephony.SmsManager

object SmsHelper {
    private const val REG_PREFIX = "MLAY_REG"

    /** Construit le message à partir du modèle personnalisable par l'admin. */
    fun buildMessageFromTemplate(template: String, lat: Double, lon: Double, timestamp: String): String {
        return template
            .replace("{lat}", lat.toString())
            .replace("{lon}", lon.toString())
            .replace("{time}", timestamp)
    }

    fun sendSms(number: String, message: String) {
        val smsManager = SmsManager.getDefault()
        val parts = smsManager.divideMessage(message)
        smsManager.sendMultipartTextMessage(number, null, parts, null, null)
    }

    /**
     * Extrait (latitude, longitude, horodatage) d'un texte, que ce soit un SMS
     * (même si l'admin a personnalisé le message) ou une charge utile Bluetooth brute
     * du type "lat,lon,timestamp". Repose sur la détection de deux nombres décimaux.
     */
    fun parsePayload(text: String): Triple<Double, Double, String>? {
        val regex = Regex("(-?\\d{1,3}\\.\\d+)[,;:\\s]+(-?\\d{1,3}\\.\\d+)")
        val match = regex.find(text) ?: return null
        return try {
            val lat = match.groupValues[1].toDouble()
            val lon = match.groupValues[2].toDouble()
            val remainder = text.substring(match.range.last + 1)
            val timestamp = remainder.trim(':', ',', ' ', ';')
            Triple(lat, lon, timestamp)
        } catch (e: Exception) {
            null
        }
    }

    fun parseRegistration(body: String): String? {
        if (!body.startsWith("$REG_PREFIX:")) return null
        return body.removePrefix("$REG_PREFIX:").trim()
    }

    fun buildRegistrationMessage(driverName: String): String = "$REG_PREFIX:$driverName"
}
