package com.mlay.service.util

import android.telephony.SmsManager

object SmsHelper {
    private const val PREFIX = "MLAY"

    fun buildMessage(lat: Double, lon: Double, timestamp: String): String {
        return "$PREFIX:$lat,$lon:$timestamp"
    }

    fun sendSms(number: String, message: String) {
        val smsManager = SmsManager.getDefault()
        val parts = smsManager.divideMessage(message)
        smsManager.sendMultipartTextMessage(number, null, parts, null, null)
    }

    fun parseMessage(body: String): Triple<Double, Double, String>? {
        if (!body.startsWith("$PREFIX:")) return null
        return try {
            val payload = body.removePrefix("$PREFIX:")
            val parts = payload.split(":")
            val coords = parts[0].split(",")
            val lat = coords[0].toDouble()
            val lon = coords[1].toDouble()
            val timestamp = if (parts.size > 1) parts[1] else ""
            Triple(lat, lon, timestamp)
        } catch (e: Exception) {
            null
        }
    }
}
