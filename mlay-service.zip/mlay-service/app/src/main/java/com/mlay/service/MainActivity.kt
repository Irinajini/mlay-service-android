package com.mlay.service

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mlay.service.admin.AdminActivity
import com.mlay.service.offlinemap.OfflineMapActivity
import com.mlay.service.util.PrefsHelper

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnClient).setOnClickListener {
            startActivity(Intent(this, RequesterActivity::class.java))
        }
        findViewById<Button>(R.id.btnLivreur).setOnClickListener {
            startActivity(Intent(this, DriverActivity::class.java))
        }
        findViewById<Button>(R.id.btnAdmin).setOnClickListener {
            promptAdminPin()
        }
        findViewById<Button>(R.id.btnCarte).setOnClickListener {
            startActivity(Intent(this, OfflineMapActivity::class.java))
        }
    }

    private fun promptAdminPin() {
        val input = EditText(this)
        input.hint = "Code PIN admin"
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD

        AlertDialog.Builder(this)
            .setTitle("Accès Admin")
            .setView(input)
            .setPositiveButton("Valider") { _, _ ->
                if (input.text.toString() == PrefsHelper.getAdminPin(this)) {
                    startActivity(Intent(this, AdminActivity::class.java))
                } else {
                    Toast.makeText(this, "Code incorrect", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
