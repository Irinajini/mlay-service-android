package com.mlay.service.util

import android.content.Context
import android.content.Intent
import android.net.Uri

object MapsHelper {
    fun openNavigation(context: Context, lat: Double, lon: Double) {
        val uri = Uri.parse("google.navigation:q=$lat,$lon&mode=d")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.setPackage("com.google.android.apps.maps")
        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
        } else {
            val fallbackUri = Uri.parse(
                "https://www.google.com/maps/dir/?api=1&destination=$lat,$lon&travelmode=driving"
            )
            context.startActivity(Intent(Intent.ACTION_VIEW, fallbackUri))
        }
    }
}
