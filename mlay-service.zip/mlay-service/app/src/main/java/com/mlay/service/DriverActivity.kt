package com.mlay.service

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mlay.service.util.BleAdvertiser
import com.mlay.service.util.BleGattServerManager
import com.mlay.service.util.MapsHelper
import com.mlay.service.util.NotificationHelper
import com.mlay.service.util.PrefsHelper
import com.mlay.service.util.SmsHelper

class DriverActivity : AppCompatActivity() {

    private lateinit var textHistory: TextView
    private lateinit var editDriverName: EditText
    private lateinit var editAdminNumber: EditText
    private lateinit var btnToggleService: Button

    private var onDuty = false
    private var gattServer: BleGattServerManager? = null

    private fun neededPermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return list.toTypedArray()
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver)

        textHistory = findViewById(R.id.textHistoryDriver)
        editDriverName = findViewById(R.id.editDriverName)
        editAdminNumber = findViewById(R.id.editAdminNumber)
        btnToggleService = findViewById(R.id.btnToggleService)

        editDriverName.setText(PrefsHelper.getDriverName(this))
        editAdminNumber.setText(PrefsHelper.getAdminNumberForDriver(this))

        requestNeededPermissions()

        btnToggleService.setOnClickListener {
            val name = editDriverName.text.toString().trim()
            if (name.isEmpty()) {
                Toast.makeText(this, "Entrez votre nom avant de vous mettre en service", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            PrefsHelper.saveDriverName(this, name)
            PrefsHelper.saveAdminNumberForDriver(this, editAdminNumber.text.toString().trim())

            if (!onDuty) startDuty(name) else stopDuty()
        }

        findViewById<Button>(R.id.btnOpenMaps).setOnClickListener {
            val requests = PrefsHelper.getReceivedRequests(this)
            if (requests.isNotEmpty()) {
                val latest = requests.last()
                MapsHelper.openNavigation(this, latest.getDouble("lat"), latest.getDouble("lon"))
            } else {
                Toast.makeText(this, "Aucune demande reçue pour le moment", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun requestNeededPermissions() {
        val missing = neededPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startDuty(name: String) {
        onDuty = true
        btnToggleService.text = "Se mettre HORS service"

        BleAdvertiser.startAdvertising(this)
        gattServer = BleGattServerManager(this) { payload ->
            runOnUiThread { handleIncomingRequest(payload, "Bluetooth") }
        }
        gattServer?.start()

        if (!PrefsHelper.hasDriverRegistered(this)) {
            val adminNumber = editAdminNumber.text.toString().trim()
            if (adminNumber.isNotEmpty()) {
                SmsHelper.sendSms(adminNumber, SmsHelper.buildRegistrationMessage(name))
            }
            PrefsHelper.setDriverRegistered(this, true)
        }

        Toast.makeText(this, "Vous êtes en service", Toast.LENGTH_SHORT).show()
    }

    private fun stopDuty() {
        onDuty = false
        btnToggleService.text = "Se mettre EN service"
        BleAdvertiser.stopAdvertising(this)
        gattServer?.stop()
        gattServer = null
        Toast.makeText(this, "Vous êtes hors service", Toast.LENGTH_SHORT).show()
    }

    private fun handleIncomingRequest(payload: String, source: String) {
        val parsed = SmsHelper.parsePayload(payload) ?: return
        val (lat, lon, timestamp) = parsed
        val display = timestamp.ifEmpty { "maintenant" }
        PrefsHelper.addReceivedRequest(this, lat, lon, display, source)
        NotificationHelper.createChannel(this)
        NotificationHelper.showNewRequestNotification(this, lat, lon)
        refreshHistory()
    }

    override fun onResume() {
        super.onResume()
        refreshHistory()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (onDuty) {
            BleAdvertiser.stopAdvertising(this)
            gattServer?.stop()
        }
    }

    private fun refreshHistory() {
        val requests = PrefsHelper.getReceivedRequests(this)
        val sb = StringBuilder()
        for (req in requests.asReversed()) {
            sb.append("• ${req.getString("timestamp")} via ${req.optString("from", "?")} — (${req.getDouble("lat")}, ${req.getDouble("lon")})\n")
        }
        textHistory.text = if (sb.isEmpty()) "En attente de demandes de course..." else sb.toString()
    }
}
