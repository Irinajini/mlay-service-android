package com.mlay.service

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mlay.service.util.MapsHelper
import com.mlay.service.util.PrefsHelper

class DriverActivity : AppCompatActivity() {

    private lateinit var textHistory: TextView

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver)

        textHistory = findViewById(R.id.textHistoryDriver)

        requestSmsPermission()

        findViewById<Button>(R.id.btnOpenMaps).setOnClickListener {
            val requests = PrefsHelper.getReceivedRequests(this)
            if (requests.isNotEmpty()) {
                val latest = requests.last()
                MapsHelper.openNavigation(this, latest.getDouble("lat"), latest.getDouble("lon"))
            } else {
                Toast.makeText(this, "Aucune demande reçue pour le moment", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHistory()
    }

    private fun requestSmsPermission() {
        val receiveSms = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECEIVE_SMS
        ) == PackageManager.PERMISSION_GRANTED
        if (!receiveSms) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECEIVE_SMS))
        }
    }

    private fun refreshHistory() {
        val requests = PrefsHelper.getReceivedRequests(this)
        val sb = StringBuilder()
        for (req in requests.asReversed()) {
            sb.append("• ${req.getString("timestamp")} de ${req.getString("from")} — (${req.getDouble("lat")}, ${req.getDouble("lon")})\n")
        }
        textHistory.text = if (sb.isEmpty()) "En attente de demandes de course..." else sb.toString()
    }
}
