package com.mlay.service.util

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.os.ParcelUuid
import android.widget.Toast

/** Annonce BLE utilisée par le livreur pour signaler qu'il est "en service". */
object BleAdvertiser {
    private var advertising = false

    @SuppressLint("MissingPermission")
    fun startAdvertising(context: Context) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            Toast.makeText(context, "Bluetooth désactivé sur cet appareil", Toast.LENGTH_SHORT).show()
            return
        }
        val advertiser = adapter.bluetoothLeAdvertiser ?: run {
            Toast.makeText(context, "Bluetooth LE non disponible sur cet appareil", Toast.LENGTH_SHORT).show()
            return
        }
        if (advertising) return

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(true)
            .build()

        val data = AdvertiseData.Builder()
            .addServiceUuid(ParcelUuid(BleConstants.SERVICE_UUID))
            .setIncludeDeviceName(true)
            .build()

        try {
            advertiser.startAdvertising(settings, data, advertiseCallback)
            advertising = true
        } catch (e: Exception) {
            Toast.makeText(context, "Erreur Bluetooth: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("MissingPermission")
    fun stopAdvertising(context: Context) {
        if (!advertising) return
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        val advertiser = adapter.bluetoothLeAdvertiser ?: return
        try {
            advertiser.stopAdvertising(advertiseCallback)
        } catch (e: Exception) {
            // ignore
        }
        advertising = false
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartFailure(errorCode: Int) {
            super.onStartFailure(errorCode)
            advertising = false
        }
    }
}
