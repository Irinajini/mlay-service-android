package com.mlay.service.offlinemap

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.modules.SqliteArchiveTileSource
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import java.io.File

/**
 * Carte 100% hors-ligne de Toliara. Nécessite un fichier "toliara.mbtiles" placé
 * par l'utilisateur dans le dossier de stockage privé de l'appli (voir README).
 * Ce fichier n'est pas fourni avec le projet : il doit être généré/téléchargé
 * séparément (ex: via un export OpenStreetMap de la zone de Toliara).
 */
class OfflineMapActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        super.onCreate(savedInstanceState)

        val mapView = MapView(this)
        setContentView(mapView)

        val mbtilesFile = File(getExternalFilesDir(null), "toliara.mbtiles")

        if (!mbtilesFile.exists()) {
            Toast.makeText(
                this,
                "Fichier toliara.mbtiles introuvable. Voir le README pour l'installer.",
                Toast.LENGTH_LONG
            ).show()
        } else {
            try {
                val archive = SqliteArchiveTileSource.getSqliteArchiveTileSource(mbtilesFile)
                mapView.tileProvider = MapTileProviderBasic(this, archive)
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Impossible de charger la carte hors-ligne : ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        mapView.setMultiTouchControls(true)
        mapView.controller.setZoom(13.0)
        mapView.controller.setCenter(GeoPoint(-23.3556, 43.6739)) // Toliara, Madagascar
    }
}
