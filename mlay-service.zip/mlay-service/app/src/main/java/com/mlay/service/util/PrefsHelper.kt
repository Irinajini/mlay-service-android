package com.mlay.service.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object PrefsHelper {
    private const val PREFS_NAME = "mlay_prefs"

    private const val KEY_DRIVER_NUMBER = "driver_number"
    private const val KEY_REQUEST_HISTORY = "request_history"
    private const val KEY_RECEIVED_HISTORY = "received_history"

    private const val KEY_ADMIN_PIN = "admin_pin"
    private const val KEY_SMS_TEMPLATE = "sms_template"
    private const val KEY_DRIVER_LIST_RAW = "driver_list_raw"
    private const val KEY_REGISTERED_DRIVERS_LOG = "registered_drivers_log"

    private const val KEY_DRIVER_NAME = "driver_name"
    private const val KEY_ADMIN_NUMBER_FOR_DRIVER = "admin_number_for_driver"
    private const val KEY_DRIVER_HAS_REGISTERED = "driver_has_registered"

    private const val DEFAULT_PIN = "1234"
    private const val DEFAULT_TEMPLATE = "MLAY:{lat},{lon}:{time}"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ---- Client : numéro du livreur utilisé pour le SMS de secours ----
    fun saveDriverNumber(context: Context, number: String) {
        prefs(context).edit().putString(KEY_DRIVER_NUMBER, number).apply()
    }

    fun getDriverNumber(context: Context): String {
        return prefs(context).getString(KEY_DRIVER_NUMBER, "") ?: ""
    }

    // ---- Historique des demandes envoyées (côté client) ----
    fun addSentRequest(context: Context, lat: Double, lon: Double, timestamp: String) {
        val array = JSONArray(prefs(context).getString(KEY_REQUEST_HISTORY, "[]"))
        val obj = JSONObject().apply {
            put("lat", lat); put("lon", lon); put("timestamp", timestamp)
        }
        array.put(obj)
        prefs(context).edit().putString(KEY_REQUEST_HISTORY, array.toString()).apply()
    }

    fun getSentRequests(context: Context): List<JSONObject> {
        val array = JSONArray(prefs(context).getString(KEY_REQUEST_HISTORY, "[]"))
        return (0 until array.length()).map { array.getJSONObject(it) }
    }

    // ---- Historique des demandes reçues (côté livreur) ----
    fun addReceivedRequest(context: Context, lat: Double, lon: Double, timestamp: String, from: String) {
        val array = JSONArray(prefs(context).getString(KEY_RECEIVED_HISTORY, "[]"))
        val obj = JSONObject().apply {
            put("lat", lat); put("lon", lon); put("timestamp", timestamp); put("from", from)
        }
        array.put(obj)
        prefs(context).edit().putString(KEY_RECEIVED_HISTORY, array.toString()).apply()
    }

    fun getReceivedRequests(context: Context): List<JSONObject> {
        val array = JSONArray(prefs(context).getString(KEY_RECEIVED_HISTORY, "[]"))
        return (0 until array.length()).map { array.getJSONObject(it) }
    }

    // ---- Admin ----
    fun getAdminPin(context: Context): String =
        prefs(context).getString(KEY_ADMIN_PIN, DEFAULT_PIN) ?: DEFAULT_PIN

    fun saveAdminPin(context: Context, pin: String) {
        prefs(context).edit().putString(KEY_ADMIN_PIN, pin).apply()
    }

    fun getSmsTemplate(context: Context): String =
        prefs(context).getString(KEY_SMS_TEMPLATE, DEFAULT_TEMPLATE) ?: DEFAULT_TEMPLATE

    fun saveSmsTemplate(context: Context, template: String) {
        prefs(context).edit().putString(KEY_SMS_TEMPLATE, template).apply()
    }

    fun getDriverListRaw(context: Context): String =
        prefs(context).getString(KEY_DRIVER_LIST_RAW, "") ?: ""

    fun saveDriverListRaw(context: Context, text: String) {
        prefs(context).edit().putString(KEY_DRIVER_LIST_RAW, text).apply()
    }

    fun addRegisteredDriver(context: Context, name: String, from: String, timestamp: String) {
        val current = getRegisteredDriversLog(context)
        val line = "• $timestamp — $name ($from)\n"
        prefs(context).edit().putString(KEY_REGISTERED_DRIVERS_LOG, line + current).apply()
    }

    fun getRegisteredDriversLog(context: Context): String =
        prefs(context).getString(KEY_REGISTERED_DRIVERS_LOG, "") ?: ""

    // ---- Livreur : identité locale ----
    fun saveDriverName(context: Context, name: String) {
        prefs(context).edit().putString(KEY_DRIVER_NAME, name).apply()
    }

    fun getDriverName(context: Context): String =
        prefs(context).getString(KEY_DRIVER_NAME, "") ?: ""

    fun saveAdminNumberForDriver(context: Context, number: String) {
        prefs(context).edit().putString(KEY_ADMIN_NUMBER_FOR_DRIVER, number).apply()
    }

    fun getAdminNumberForDriver(context: Context): String =
        prefs(context).getString(KEY_ADMIN_NUMBER_FOR_DRIVER, "") ?: ""

    fun hasDriverRegistered(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DRIVER_HAS_REGISTERED, false)

    fun setDriverRegistered(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_DRIVER_HAS_REGISTERED, value).apply()
    }
}
