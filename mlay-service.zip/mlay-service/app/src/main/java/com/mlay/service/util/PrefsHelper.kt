package com.mlay.service.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object PrefsHelper {
    private const val PREFS_NAME = "mlay_prefs"
    private const val KEY_DRIVER_NUMBER = "driver_number"
    private const val KEY_REQUEST_HISTORY = "request_history"
    private const val KEY_RECEIVED_HISTORY = "received_history"

    fun saveDriverNumber(context: Context, number: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_DRIVER_NUMBER, number).apply()
    }

    fun getDriverNumber(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_DRIVER_NUMBER, "") ?: ""
    }

    fun addSentRequest(context: Context, lat: Double, lon: Double, timestamp: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray(prefs.getString(KEY_REQUEST_HISTORY, "[]"))
        val obj = JSONObject()
        obj.put("lat", lat)
        obj.put("lon", lon)
        obj.put("timestamp", timestamp)
        array.put(obj)
        prefs.edit().putString(KEY_REQUEST_HISTORY, array.toString()).apply()
    }

    fun getSentRequests(context: Context): List<JSONObject> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray(prefs.getString(KEY_REQUEST_HISTORY, "[]"))
        val list = mutableListOf<JSONObject>()
        for (i in 0 until array.length()) {
            list.add(array.getJSONObject(i))
        }
        return list
    }

    fun addReceivedRequest(context: Context, lat: Double, lon: Double, timestamp: String, from: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray(prefs.getString(KEY_RECEIVED_HISTORY, "[]"))
        val obj = JSONObject()
        obj.put("lat", lat)
        obj.put("lon", lon)
        obj.put("timestamp", timestamp)
        obj.put("from", from)
        array.put(obj)
        prefs.edit().putString(KEY_RECEIVED_HISTORY, array.toString()).apply()
    }

    fun getReceivedRequests(context: Context): List<JSONObject> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray(prefs.getString(KEY_RECEIVED_HISTORY, "[]"))
        val list = mutableListOf<JSONObject>()
        for (i in 0 until array.length()) {
            list.add(array.getJSONObject(i))
        }
        return list
    }
}
