package com.mlay.service.util

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid

/**
 * Côté client : cherche le livreur "en service" le plus proche via Bluetooth (par
 * intensité du signal), puis lui envoie directement la demande de course sans SMS
 * ni internet. Si aucun livreur n'est trouvé, l'appelant doit basculer sur le SMS.
 */
class BleScanner(
    private val context: Context,
    private val onStatus: (String) -> Unit,
    private val onSent: () -> Unit,
    private val onFailed: () -> Unit
) {
    private var scanner: BluetoothLeScanner? = null
    private var bestDevice: BluetoothDevice? = null
    private var bestRssi: Int = Int.MIN_VALUE
    private var scanning = false
    private var gatt: BluetoothGatt? = null
    private var finished = false

    @SuppressLint("MissingPermission")
    fun scanForNearestDriver(timeoutMs: Long, payload: String) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            onStatus("Bluetooth désactivé")
            onFailed()
            return
        }
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            onFailed()
            return
        }
        bestDevice = null
        bestRssi = Int.MIN_VALUE
        finished = false

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(BleConstants.SERVICE_UUID))
            .build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        onStatus("Recherche d'un livreur à proximité (Bluetooth)...")
        scanning = true
        try {
            scanner?.startScan(listOf(filter), settings, scanCallback)
        } catch (e: Exception) {
            onFailed()
            return
        }

        Handler(Looper.getMainLooper()).postDelayed({
            if (scanning) {
                stopScanOnly()
                val device = bestDevice
                if (device == null) {
                    onStatus("Aucun livreur trouvé via Bluetooth à proximité")
                    finish { onFailed() }
                } else {
                    onStatus("Livreur trouvé, envoi en cours...")
                    connectAndSend(device, payload)
                }
            }
        }, timeoutMs)
    }

    @SuppressLint("MissingPermission")
    private fun stopScanOnly() {
        if (scanning) {
            try {
                scanner?.stopScan(scanCallback)
            } catch (e: Exception) {
                // ignore
            }
            scanning = false
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (result.rssi > bestRssi) {
                bestRssi = result.rssi
                bestDevice = result.device
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectAndSend(device: BluetoothDevice, payload: String) {
        gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    g.requestMtu(247)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    finish { onFailed() }
                }
            }

            override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
                g.discoverServices()
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                val service = g.getService(BleConstants.SERVICE_UUID)
                val characteristic = service?.getCharacteristic(BleConstants.REQUEST_CHARACTERISTIC_UUID)
                if (characteristic != null) {
                    characteristic.value = payload.toByteArray(Charsets.UTF_8)
                    g.writeCharacteristic(characteristic)
                } else {
                    g.disconnect()
                }
            }

            override fun onCharacteristicWrite(
                g: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
            ) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    finish { onSent() }
                } else {
                    finish { onFailed() }
                }
                g.disconnect()
            }
        })
    }

    private fun finish(action: () -> Unit) {
        if (finished) return
        finished = true
        action()
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        stopScanOnly()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
    }
}
