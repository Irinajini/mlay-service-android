package com.mlay.service.util

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue

/**
 * Point d'accès unique à Firebase Authentication et Realtime Database.
 * L'admin est reconnu automatiquement par son adresse e-mail : aucune liste
 * séparée à gérer, aucun bouton caché nécessaire.
 */
object FirebaseRepository {

    const val ADMIN_EMAIL = "andriafalinomenjanahary@gmail.com"

    const val ROLE_CLIENT = "client"
    const val ROLE_DRIVER = "livreur"
    const val ROLE_ADMIN = "admin"

    fun isAdminEmail(email: String): Boolean =
        email.trim().equals(ADMIN_EMAIL, ignoreCase = true)

    fun auth(): FirebaseAuth = FirebaseAuth.getInstance()

    fun db(): FirebaseDatabase = FirebaseDatabase.getInstance()

    fun currentUid(): String? = auth().currentUser?.uid
    fun currentEmail(): String? = auth().currentUser?.email

    fun isLoggedIn(): Boolean = auth().currentUser != null

    fun signOut() {
        auth().signOut()
    }

    /**
     * Crée (ou met à jour) la fiche du profil utilisateur. Si l'e-mail correspond
     * à l'adresse de l'admin, le rôle "admin" est forcé automatiquement, peu importe
     * ce qui a été choisi dans le formulaire.
     */
    fun saveUserProfile(uid: String, email: String, requestedRole: String, onDone: (Boolean, String) -> Unit) {
        val role = if (isAdminEmail(email)) ROLE_ADMIN else requestedRole

        val profile = mapOf(
            "uid" to uid,
            "email" to email,
            "role" to role,
            "active" to true,
            "createdAt" to ServerValue.TIMESTAMP
        )

        db().reference.child("users").child(uid).setValue(profile)
            .addOnSuccessListener {
                if (role == ROLE_DRIVER) {
                    val driver = mapOf(
                        "uid" to uid,
                        "email" to email,
                        "available" to false,
                        "latitude" to 0.0,
                        "longitude" to 0.0,
                        "updatedAt" to ServerValue.TIMESTAMP
                    )
                    db().reference.child("drivers").child(uid).setValue(driver)
                        .addOnSuccessListener { onDone(true, role) }
                        .addOnFailureListener { onDone(false, it.localizedMessage ?: "Erreur") }
                } else {
                    onDone(true, role)
                }
            }
            .addOnFailureListener { onDone(false, it.localizedMessage ?: "Erreur") }
    }

    /** Récupère le rôle stocké pour l'utilisateur connecté (ou null si absent). */
    fun loadRole(uid: String, onDone: (String?) -> Unit) {
        db().reference.child("users").child(uid).child("role").get()
            .addOnSuccessListener { onDone(it.getValue(String::class.java)) }
            .addOnFailureListener { onDone(null) }
    }
}
