package com.mlay.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.mlay.service.util.NotificationHelper
import com.mlay.service.util.PrefsHelper
import com.mlay.service.util.SmsHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        for (sms in messages) {
            val body = sms.messageBody ?: continue
            val from = sms.originatingAddress ?: ""

            val regName = SmsHelper.parseRegistration(body)
            if (regName != null) {
                val timestamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())
                PrefsHelper.addRegisteredDriver(context, regName, from, timestamp)
                continue
            }

            val parsed = SmsHelper.parsePayload(body) ?: continue
            val (lat, lon, timestamp) = parsed
            val display = timestamp.ifEmpty {
                SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())
            }

            PrefsHelper.addReceivedRequest(context, lat, lon, display, from)
            NotificationHelper.createChannel(context)
            NotificationHelper.showNewRequestNotification(context, lat, lon)
        }
    }
}
