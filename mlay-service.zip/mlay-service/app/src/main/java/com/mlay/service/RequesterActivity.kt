package com.mlay.service

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mlay.service.util.LocationHelper
import com.mlay.service.util.PrefsHelper
import com.mlay.service.util.SmsHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RequesterActivity : AppCompatActivity() {

    private lateinit var editDriverNumber: EditText
    private lateinit var textStatus: TextView
    private lateinit var textHistory: TextView

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true &&
            results[Manifest.permission.SEND_SMS] == true
        ) {
            requestRide()
        } else {
            Toast.makeText(this, "Permissions nécessaires refusées", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_requester)

        editDriverNumber = findViewById(R.id.editDriverNumber)
        textStatus = findViewById(R.id.textStatus)
        textHistory = findViewById(R.id.textHistory)

        editDriverNumber.setText(PrefsHelper.getDriverNumber(this))

        findViewById<Button>(R.id.btnRequestRide).setOnClickListener {
            val number = editDriverNumber.text.toString().trim()
            if (number.isEmpty()) {
                Toast.makeText(this, "Entrez le numéro du livreur", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            PrefsHelper.saveDriverNumber(this, number)
            checkPermissionsAndRequest()
        }

        refreshHistory()
    }

    private fun checkPermissionsAndRequest() {
        val fineLocation = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val sendSms = ContextCompat.checkSelfPermission(
            this, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED

        if (fineLocation && sendSms) {
            requestRide()
        } else {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.SEND_SMS)
            )
        }
    }

    private fun requestRide() {
        textStatus.text = "Recherche de votre position..."
        LocationHelper.getCurrentLocation(this, onResult = { lat, lon ->
            val timestamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())
            val message = SmsHelper.buildMessage(lat, lon, timestamp)
            val number = editDriverNumber.text.toString().trim()
            SmsHelper.sendSms(number, message)
            PrefsHelper.addSentRequest(this, lat, lon, timestamp)
            textStatus.text = "Demande envoyée à $number ✔"
            refreshHistory()
        }, onError = {
            textStatus.text = "Impossible d'obtenir la position GPS. Activez le GPS et réessayez."
        })
    }

    private fun refreshHistory() {
        val requests = PrefsHelper.getSentRequests(this)
        val sb = StringBuilder()
        for (req in requests.asReversed()) {
            sb.append("• ${req.getString("timestamp")} — (${req.getDouble("lat")}, ${req.getDouble("lon")})\n")
        }
        textHistory.text = if (sb.isEmpty()) "Aucune course demandée pour le moment." else sb.toString()
    }
}
