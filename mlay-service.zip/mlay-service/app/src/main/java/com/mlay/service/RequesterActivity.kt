package com.mlay.service

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.mlay.service.util.BleScanner
import com.mlay.service.util.LocationHelper
import com.mlay.service.util.PrefsHelper
import com.mlay.service.util.SmsHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RequesterActivity : AppCompatActivity() {

    private lateinit var editDriverNumber: EditText
    private lateinit var textStatus: TextView
    private lateinit var textHistory: TextView
    private var bleScanner: BleScanner? = null

    private fun neededPermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return list.toTypedArray()
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            requestRide()
        } else {
            Toast.makeText(this, "Certaines permissions ont été refusées", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_requester)

        editDriverNumber = findViewById(R.id.editDriverNumber)
        textStatus = findViewById(R.id.textStatus)
        textHistory = findViewById(R.id.textHistory)

        editDriverNumber.setText(PrefsHelper.getDriverNumber(this))

        findViewById<Button>(R.id.btnRequestRide).setOnClickListener {
            val number = editDriverNumber.text.toString().trim()
            if (number.isEmpty()) {
                Toast.makeText(
                    this,
                    "Entrez le numéro du livreur (utilisé seulement si le SMS de secours est nécessaire)",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            PrefsHelper.saveDriverNumber(this, number)
            checkPermissionsAndRequest()
        }

        refreshHistory()
    }

    private fun checkPermissionsAndRequest() {
        val missing = neededPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            requestRide()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun requestRide() {
        textStatus.text = "Recherche de votre position..."
        LocationHelper.getCurrentLocation(this, onResult = { lat, lon ->
            val timestamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())
            val payload = "$lat,$lon,$timestamp"

            textStatus.text = "Position trouvée. Recherche d'un livreur via Bluetooth..."
            bleScanner = BleScanner(
                context = this,
                onStatus = { status -> runOnUiThread { textStatus.text = status } },
                onSent = {
                    runOnUiThread {
                        textStatus.text = "Course envoyée via Bluetooth ✔ (aucun SMS, aucune donnée nécessaire)"
                        PrefsHelper.addSentRequest(this, lat, lon, timestamp)
                        refreshHistory()
                    }
                },
                onFailed = {
                    runOnUiThread { sendViaSms(lat, lon, timestamp) }
                }
            )
            bleScanner?.scanForNearestDriver(timeoutMs = 6000, payload = payload)
        }, onError = {
            textStatus.text = "Impossible d'obtenir la position GPS. Activez le GPS et réessayez."
        })
    }

    private fun sendViaSms(lat: Double, lon: Double, timestamp: String) {
        textStatus.text = "Aucun livreur trouvé en Bluetooth, envoi par SMS..."
        val template = PrefsHelper.getSmsTemplate(this)
        val message = SmsHelper.buildMessageFromTemplate(template, lat, lon, timestamp)
        val number = editDriverNumber.text.toString().trim()
        SmsHelper.sendSms(number, message)
        PrefsHelper.addSentRequest(this, lat, lon, timestamp)
        textStatus.text = "Demande envoyée par SMS à $number ✔"
        refreshHistory()
    }

    private fun refreshHistory() {
        val requests = PrefsHelper.getSentRequests(this)
        val sb = StringBuilder()
        for (req in requests.asReversed()) {
            sb.append("• ${req.getString("timestamp")} — (${req.getDouble("lat")}, ${req.getDouble("lon")})\n")
        }
        textHistory.text = if (sb.isEmpty()) "Aucune course demandée pour le moment." else sb.toString()
    }

    override fun onDestroy() {
        super.onDestroy()
        bleScanner?.stop()
    }
}
