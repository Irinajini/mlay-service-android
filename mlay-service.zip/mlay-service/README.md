# M'lay Service

Application Android de livraison/transport fonctionnant **sans connexion internet**, en utilisant les SMS pour transmettre la position du client au livreur.

## Fonctionnement

1. **Client** : ouvre l'appli, choisit "Je suis Client", entre le numéro du livreur, appuie sur "Demander une course maintenant".
   - L'appli récupère automatiquement la position GPS.
   - Un SMS formaté (`MLAY:latitude,longitude:date`) est envoyé au livreur — pas besoin de data mobile, juste du réseau GSM classique.

2. **Livreur** : ouvre l'appli, choisit "Je suis Livreur".
   - Dès qu'un SMS `MLAY:...` arrive, l'appli le détecte automatiquement, l'ajoute à l'historique et affiche une notification.
   - En appuyant sur "Ouvrir la dernière demande dans Maps" (ou sur la notification), l'appli lance directement **Google Maps** avec l'itinéraire vers le client déjà pointé.

## Limite importante concernant le "hors ligne"

- L'envoi de la demande (SMS) et sa réception fonctionnent **sans internet**, uniquement avec le réseau GSM/SMS classique — c'est le cœur de l'originalité de l'appli.
- En revanche, **la navigation dans Google Maps elle-même nécessite internet** (ou une carte préalablement téléchargée). Pour une navigation 100% hors-ligne côté livreur, il faut que celui-ci télécharge au préalable la zone de Toliara dans l'appli Google Maps : `Menu Google Maps → Cartes hors connexion → Sélectionner une zone`. Cela ne nécessite aucun développement supplémentaire et fonctionne dès aujourd'hui.

## Compiler l'APK via GitHub Actions (sans installer Android Studio)

1. Crée un nouveau dépôt sur GitHub (ex: `mlay-service`).
2. Pousse tout le contenu de ce dossier dedans :
   ```bash
   git init
   git add .
   git commit -m "Premier commit - M'lay Service"
   git branch -M main
   git remote add origin https://github.com/TON_USER/mlay-service.git
   git push -u origin main
   ```
3. Va dans l'onglet **Actions** de ton dépôt GitHub. Le workflow "Build APK" se lance automatiquement.
4. Une fois le build terminé (icône verte ✔), clique dessus puis télécharge l'artifact **mlay-service-debug-apk** en bas de page — c'est ton fichier `.apk` prêt à installer.

## Installer l'APK sur un téléphone Android

1. Transfère le fichier `.apk` téléchargé sur le téléphone (câble USB, Bluetooth, etc.).
2. Sur le téléphone, autorise l'installation d'applications de sources inconnues si demandé.
3. Ouvre le fichier `.apk` et installe.
4. Au premier lancement, accepte les permissions demandées (position GPS, SMS) — elles sont indispensables au fonctionnement de l'appli.

## Prochaines évolutions possibles

- Ajouter une liste de plusieurs livreurs enregistrés (broadcast à plusieurs numéros).
- Ajouter une carte offline (OSMDroid + fichier `.mbtiles` de Toliara) pour afficher un plan directement dans l'appli sans passer par Google Maps.
- Ajouter un système d'accusé de réception (le livreur répond par SMS "J'arrive").
