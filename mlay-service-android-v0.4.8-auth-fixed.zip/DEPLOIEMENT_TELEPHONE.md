# Compilation depuis un téléphone

Le projet est prêt pour GitHub Actions.

1. Les dossiers `.github`, `app` et les fichiers Gradle doivent être visibles directement à la racine du dépôt GitHub.
2. Dans GitHub, ouvrir **Actions** puis **Build Mlay Service APK**.
3. Appuyer sur **Run workflow**.
4. Lorsque la compilation est verte, ouvrir l'exécution et télécharger l'artefact **mlay-service-debug-apk**.
5. Décompresser l'artefact et installer `app-debug.apk`.

## Firebase

Pour activer Firebase, ajouter le véritable fichier `google-services.json` dans `app/` avant la compilation. Ne jamais publier ce fichier dans un dépôt public.
