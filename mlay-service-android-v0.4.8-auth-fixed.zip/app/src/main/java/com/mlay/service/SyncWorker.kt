package com.mlay.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

class SyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("mlay", Context.MODE_PRIVATE)
        val endpoint = prefs.getString("sync_endpoint", "")?.trim().orEmpty()
        if (endpoint.isBlank()) return Result.success()

        val queue = JSONArray(prefs.getString("pending_requests", "[]"))
        if (queue.length() == 0) return Result.success()

        return try {
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12_000
                readTimeout = 12_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            connection.outputStream.use { it.write(queue.toString().toByteArray(Charsets.UTF_8)) }
            val ok = connection.responseCode in 200..299
            connection.disconnect()
            if (ok) {
                prefs.edit().putString("pending_requests", "[]").putLong("last_sync", System.currentTimeMillis()).apply()
                Result.success()
            } else Result.retry()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
