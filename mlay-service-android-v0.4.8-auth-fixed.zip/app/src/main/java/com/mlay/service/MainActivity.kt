package com.mlay.service

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.gms.location.LocationServices
import com.mlay.service.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private var latitude: Double? = null
    private var longitude: Double? = null
    private val fused by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private val relay by lazy { BluetoothRelayManager(this) }
    private var pendingSmsPayload: JSONObject? = null

    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true) captureLocation()
        else b.status.text = "Permission GPS refusée."
    }

    private val smsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingSmsPayload?.let { sendAutomaticSms(it) }
        else b.status.text = "Permission SMS refusée. Vous pouvez utiliser le partage manuel."
    }

    private val bluetoothPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val ok = result.values.all { it }
        if (ok) sendByBluetooth(payload()) else fallbackToSms(payload(), "Bluetooth non autorisé")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        restoreLastRequest()
        refreshConnectionLabel()

        b.captureGps.setOnClickListener { ensureLocationPermission() }
        b.saveRequest.setOnClickListener { saveAndDispatch() }
        b.shareRequest.setOnClickListener { shareRequest() }
        b.openNavigation.setOnClickListener { openNavigation() }
        b.adminPanel.setOnClickListener { startActivity(Intent(this, AdminActivity::class.java)) }
        b.openOfflineMap.setOnClickListener {
            startActivity(Intent(this, OfflineMapActivity::class.java).apply {
                putExtra("lat", latitude ?: -23.3516); putExtra("lon", longitude ?: 43.6855)
            })
        }
    }

    override fun onResume() {
        super.onResume()
        refreshConnectionLabel()
        scheduleOnlineSync()
    }

    private fun ensureLocationPermission() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED) captureLocation()
        else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    private fun captureLocation() {
        b.status.text = "Recherche de la position…"
        try {
            fused.lastLocation.addOnSuccessListener { last: Location? ->
                if (last != null) setCoordinates(last.latitude, last.longitude)
                else b.status.text = "Position indisponible. Activez le GPS puis réessayez."
            }.addOnFailureListener { b.status.text = "Erreur GPS : ${it.message}" }
        } catch (_: SecurityException) { b.status.text = "Permission GPS manquante." }
    }

    private fun setCoordinates(lat: Double, lon: Double) {
        latitude = lat; longitude = lon
        b.coordinates.text = "Latitude: %.6f\nLongitude: %.6f".format(Locale.US, lat, lon)
        b.status.text = "Position captée."
    }

    private fun payload(): JSONObject {
        val id = "MLAY-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        return JSONObject().apply {
            put("id", id); put("nom", b.customerName.text.toString().trim())
            put("telephone", b.phone.text.toString().trim()); put("service", b.serviceType.text.toString().trim())
            put("details", b.details.text.toString().trim()); put("latitude", latitude); put("longitude", longitude)
            put("cree_le", System.currentTimeMillis()); put("statut", "EN_ATTENTE")
        }
    }

    private fun saveAndDispatch() {
        if (latitude == null || longitude == null) { b.status.text = "Captez d'abord la position GPS."; return }
        val p = payload()
        saveLocal(p)
        if (isOnline()) {
            enqueuePending(p)
            FirebaseRepository.saveRequest(this, p) { ok, message ->
                runOnUiThread {
                    b.status.text = if (ok) message else "$message. Conservée dans la file locale."
                    if (!ok) scheduleOnlineSync()
                }
            }
        } else {
            b.status.text = "Hors connexion : recherche d'un livreur par Bluetooth…"
            ensureBluetoothThenSend(p)
        }
    }

    private fun saveLocal(p: JSONObject) {
        getSharedPreferences("mlay", MODE_PRIVATE).edit().putString("last_request", p.toString()).apply()
    }

    private fun enqueuePending(p: JSONObject) {
        val prefs = getSharedPreferences("mlay", MODE_PRIVATE)
        val array = runCatching { JSONArray(prefs.getString("pending_requests", "[]")) }.getOrDefault(JSONArray())
        array.put(p)
        prefs.edit().putString("pending_requests", array.toString()).apply()
    }

    private fun scheduleOnlineSync() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniqueWork("mlay-online-sync", ExistingWorkPolicy.KEEP, request)
    }

    private fun ensureBluetoothThenSend(p: JSONObject) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val permissions = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
            if (permissions.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
                bluetoothPermission.launch(permissions); return
            }
        }
        sendByBluetooth(p)
    }

    private fun sendByBluetooth(p: JSONObject) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) { fallbackToSms(p, "Bluetooth indisponible"); return }
        relay.sendToKnownDriver(compactMessage(p)) { success, message ->
            runOnUiThread {
                if (success) b.status.text = message else fallbackToSms(p, message)
            }
        }
    }

    private fun fallbackToSms(p: JSONObject, reason: String) {
        b.status.text = "$reason. Bascule vers le SMS automatique."
        pendingSmsPayload = p
        val permission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
        if (permission == PackageManager.PERMISSION_GRANTED) sendAutomaticSms(p)
        else smsPermission.launch(Manifest.permission.SEND_SMS)
    }

    private fun sendAutomaticSms(p: JSONObject) {
        val destination = b.driverSmsNumber.text.toString().trim()
        if (destination.isBlank()) {
            b.status.text = "Ajoutez le numéro SMS de dispatch/livreur."
            return
        }
        try {
            val text = compactMessage(p)
            val manager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            val parts = manager.divideMessage(text)
            manager.sendMultipartTextMessage(destination, null, parts, null, null)
            b.status.text = "SMS automatique envoyé au $destination (${text.length} caractères)."
        } catch (e: Exception) {
            b.status.text = "Échec SMS : ${e.message}"
        } finally { pendingSmsPayload = null }
    }

    private fun compactMessage(p: JSONObject): String {
        val template = getSharedPreferences("mlay", MODE_PRIVATE).getString("sms_template", AdminActivity.DEFAULT_SMS_TEMPLATE)
            ?: AdminActivity.DEFAULT_SMS_TEMPLATE
        return template
            .replace("{id}", p.optString("id"))
            .replace("{service}", p.optString("service"))
            .replace("{lat}", String.format(Locale.US, "%.5f", p.optDouble("latitude")))
            .replace("{lon}", String.format(Locale.US, "%.5f", p.optDouble("longitude")))
            .replace("{phone}", p.optString("telephone"))
            .replace("{name}", p.optString("nom"))
            .replace("{details}", p.optString("details"))
            .replace(Regex("\\s+"), " ").trim().take(320)
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
    }

    private fun refreshConnectionLabel() {
        b.connectionStatus.text = if (isOnline()) "Connexion : Internet disponible" else "Connexion : hors ligne — Bluetooth puis SMS"
    }

    private fun shareRequest() {
        if (latitude == null || longitude == null) { b.status.text = "Captez d'abord la position GPS."; return }
        val text = compactMessage(payload())
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Transmettre la course"))
    }

    private fun openNavigation() {
        val lat = latitude; val lon = longitude
        if (lat == null || lon == null) { b.status.text = "Aucune destination GPS."; return }
        val google = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$lat,$lon&mode=d")).apply { setPackage("com.google.android.apps.maps") }
        if (google.resolveActivity(packageManager) != null) startActivity(google)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(M'lay client)")))
    }

    private fun restoreLastRequest() {
        val prefs = getSharedPreferences("mlay", MODE_PRIVATE)
        val raw = prefs.getString("last_request", null) ?: return
        runCatching {
            val p = JSONObject(raw)
            b.customerName.setText(p.optString("nom")); b.phone.setText(p.optString("telephone"))
            b.serviceType.setText(p.optString("service")); b.details.setText(p.optString("details"))
            if (!p.isNull("latitude") && !p.isNull("longitude")) setCoordinates(p.getDouble("latitude"), p.getDouble("longitude"))
            b.status.text = "Dernière demande restaurée depuis le stockage local."
        }
    }
}
