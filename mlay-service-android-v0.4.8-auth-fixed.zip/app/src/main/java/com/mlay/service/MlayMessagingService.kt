package com.mlay.service
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
class MlayMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        val uid=FirebaseRepository.currentUserId() ?: return
        if (FirebaseRepository.available(this)) com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("users").document(uid).update("fcmToken",token)
    }
    override fun onMessageReceived(message: RemoteMessage) { super.onMessageReceived(message) }
}
