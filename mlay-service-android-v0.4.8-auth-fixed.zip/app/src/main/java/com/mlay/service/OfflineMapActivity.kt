package com.mlay.service

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mlay.service.databinding.ActivityOfflineMapBinding
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker

class OfflineMapActivity : AppCompatActivity() {
    private lateinit var b: ActivityOfflineMapBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        b = ActivityOfflineMapBinding.inflate(layoutInflater); setContentView(b.root)
        val lat = intent.getDoubleExtra("lat", -23.3516)
        val lon = intent.getDoubleExtra("lon", 43.6855)
        b.map.setTileSource(TileSourceFactory.MAPNIK)
        b.map.setMultiTouchControls(true)
        b.map.controller.setZoom(15.0)
        b.map.controller.setCenter(GeoPoint(lat, lon))
        b.map.overlays.add(Marker(b.map).apply {
            position = GeoPoint(lat, lon); title = "Position M'lay"; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        })
    }
    override fun onResume() { super.onResume(); b.map.onResume() }
    override fun onPause() { b.map.onPause(); super.onPause() }
}
