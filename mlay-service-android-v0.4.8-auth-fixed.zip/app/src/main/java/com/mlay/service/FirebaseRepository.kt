package com.mlay.service

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import org.json.JSONObject

object FirebaseRepository {
    fun available(context: Context): Boolean = runCatching {
        FirebaseApp.initializeApp(context) != null || FirebaseApp.getApps(context).isNotEmpty()
    }.getOrDefault(false)

    fun currentUserId(): String? = runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull()

    fun saveRequest(context: Context, p: JSONObject, onDone: (Boolean, String) -> Unit) {
        if (!available(context)) { onDone(false, "Firebase non configuré"); return }
        val data = mutableMapOf<String, Any?>(
            "id" to p.optString("id"), "clientId" to currentUserId(),
            "nom" to p.optString("nom"), "telephone" to p.optString("telephone"),
            "service" to p.optString("service"), "details" to p.optString("details"),
            "latitude" to p.optDouble("latitude"), "longitude" to p.optDouble("longitude"),
            "creeLe" to p.optLong("cree_le"), "statut" to p.optString("statut"),
            "modeTransmission" to "internet", "syncStatus" to "SYNCED"
        )
        FirebaseFirestore.getInstance().collection("requests").document(p.optString("id"))
            .set(data).addOnSuccessListener { onDone(true, "Demande synchronisée avec Firebase") }
            .addOnFailureListener { onDone(false, it.message ?: "Erreur Firebase") }
    }

    fun saveSmsTemplate(context: Context, template: String, onDone: (Boolean) -> Unit) {
        if (!available(context)) { onDone(false); return }
        FirebaseFirestore.getInstance().collection("config").document("dispatch")
            .set(mapOf("smsTemplate" to template), SetOptions.merge())
            .addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) }
    }

    fun loadSmsTemplate(context: Context, onDone: (String?) -> Unit) {
        if (!available(context)) { onDone(null); return }
        FirebaseFirestore.getInstance().collection("config").document("dispatch").get()
            .addOnSuccessListener { onDone(it.getString("smsTemplate")) }
            .addOnFailureListener { onDone(null) }
    }
}
