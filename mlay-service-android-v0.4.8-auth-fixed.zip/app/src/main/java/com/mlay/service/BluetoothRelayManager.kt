package com.mlay.service

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.content.Context
import java.io.IOException
import java.util.UUID
import kotlin.concurrent.thread

class BluetoothRelayManager(private val context: Context) {
    companion object {
        private const val SERVICE_NAME = "MLAY_RELAY"
        private val SERVICE_UUID: UUID = UUID.fromString("9bf7fbb0-1094-4a41-b9f3-8a35edba9271")
    }

    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    @SuppressLint("MissingPermission")
    fun sendToKnownDriver(message: String, callback: (Boolean, String) -> Unit) {
        val candidates = adapter?.bondedDevices
            ?.filter { it.name?.startsWith("MLAY-LIVREUR", ignoreCase = true) == true }
            .orEmpty()
        if (candidates.isEmpty()) {
            callback(false, "Aucun téléphone livreur MLAY appairé n'a été trouvé.")
            return
        }
        thread {
            var lastError = "Connexion Bluetooth impossible."
            for (device in candidates) {
                try {
                    val socket = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
                    adapter?.cancelDiscovery()
                    socket.connect()
                    socket.outputStream.use { it.write(message.toByteArray(Charsets.UTF_8)) }
                    socket.close()
                    callback(true, "Demande relayée au livreur ${device.name}.")
                    return@thread
                } catch (e: IOException) {
                    lastError = e.message ?: lastError
                }
            }
            callback(false, lastError)
        }
    }

    @SuppressLint("MissingPermission")
    fun startDriverReceiver(onMessage: (String) -> Unit): BluetoothServerSocket? {
        val server = adapter?.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SERVICE_UUID) ?: return null
        thread {
            while (!Thread.currentThread().isInterrupted) {
                try {
                    val socket = server.accept()
                    val text = socket.inputStream.bufferedReader().use { it.readText() }
                    socket.close()
                    if (text.isNotBlank()) onMessage(text)
                } catch (_: IOException) {
                    break
                }
            }
        }
        return server
    }
}
