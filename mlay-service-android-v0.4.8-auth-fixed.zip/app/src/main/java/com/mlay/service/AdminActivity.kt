package com.mlay.service

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mlay.service.databinding.ActivityAdminBinding

class AdminActivity : AppCompatActivity() {
    private lateinit var b: ActivityAdminBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(b.root)
        val prefs = getSharedPreferences("mlay", MODE_PRIVATE)
        b.smsTemplate.setText(prefs.getString("sms_template", DEFAULT_SMS_TEMPLATE))
        b.syncEndpoint.setText(prefs.getString("sync_endpoint", ""))
        FirebaseRepository.loadSmsTemplate(this) { cloud ->
            if (!cloud.isNullOrBlank()) runOnUiThread { b.smsTemplate.setText(cloud) }
        }
        b.saveAdmin.setOnClickListener {
            val template = b.smsTemplate.text.toString().trim().ifBlank { DEFAULT_SMS_TEMPLATE }
            prefs.edit()
                .putString("sms_template", template)
                .putString("sync_endpoint", b.syncEndpoint.text.toString().trim())
                .apply()
            FirebaseRepository.saveSmsTemplate(this, template) { synced ->
                runOnUiThread { b.adminStatus.text = if (synced) "Configuration enregistrée localement et dans Firebase." else "Configuration locale enregistrée. Firebase non configuré ou accès refusé." }
            }
        }
    }

    companion object {
        const val DEFAULT_SMS_TEMPLATE = "MLAY {id} {service} GPS:{lat},{lon} T:{phone}"
    }
}
