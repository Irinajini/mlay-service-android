package com.mlay.service

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.mlay.service.databinding.ActivityAuthBinding

class AuthActivity : AppCompatActivity() {
    private lateinit var b: ActivityAuthBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(b.root)

        if (!FirebaseRepository.available(this)) {
            b.status.text = "Ajoutez app/google-services.json pour activer Firebase."
        }

        b.login.setOnClickListener { login() }
        b.registerClient.setOnClickListener { register("client") }
        b.registerDriver.setOnClickListener { register("livreur") }
        b.continueOffline.setOnClickListener { openMain() }
    }

    private fun credentialsOrNull(): Pair<String, String>? {
        val email = b.email.text?.toString()?.trim().orEmpty()
        val password = b.password.text?.toString().orEmpty()

        b.email.error = null
        b.password.error = null

        if (email.isBlank()) {
            b.email.error = "Saisissez votre adresse e-mail."
            b.email.requestFocus()
            return null
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            b.email.error = "Adresse e-mail invalide."
            b.email.requestFocus()
            return null
        }
        if (password.isBlank()) {
            b.password.error = "Saisissez votre mot de passe."
            b.password.requestFocus()
            return null
        }
        if (password.length < 6) {
            b.password.error = "Le mot de passe doit contenir au moins 6 caractères."
            b.password.requestFocus()
            return null
        }
        return email to password
    }

    private fun login() {
        if (!FirebaseRepository.available(this)) {
            b.status.text = "Firebase n'est pas configuré."
            return
        }

        val (email, password) = credentialsOrNull() ?: return
        setBusy(true)

        try {
            FirebaseAuth.getInstance()
                .signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { openMain() }
                .addOnFailureListener {
                    setBusy(false)
                    b.status.text = it.localizedMessage ?: "Connexion impossible."
                }
        } catch (e: IllegalArgumentException) {
            setBusy(false)
            b.status.text = "Vérifiez l'adresse e-mail et le mot de passe."
        }
    }

    private fun register(role: String) {
        if (!FirebaseRepository.available(this)) {
            b.status.text = "Firebase n'est pas configuré."
            return
        }

        val (email, password) = credentialsOrNull() ?: return
        setBusy(true)

        try {
            FirebaseAuth.getInstance()
                .createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    if (uid.isNullOrBlank()) {
                        setBusy(false)
                        b.status.text = "Compte créé, mais identifiant utilisateur introuvable."
                        return@addOnSuccessListener
                    }

                    val profile = mapOf(
                        "email" to email,
                        "role" to role,
                        "active" to true,
                        "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                    )

                    FirebaseFirestore.getInstance()
                        .collection("users")
                        .document(uid)
                        .set(profile)
                        .addOnSuccessListener { openMain() }
                        .addOnFailureListener {
                            setBusy(false)
                            b.status.text = it.localizedMessage
                                ?: "Compte créé, mais profil Firestore non enregistré."
                        }
                }
                .addOnFailureListener {
                    setBusy(false)
                    b.status.text = it.localizedMessage ?: "Création du compte impossible."
                }
        } catch (e: IllegalArgumentException) {
            setBusy(false)
            b.status.text = "Vérifiez l'adresse e-mail et le mot de passe."
        }
    }

    private fun setBusy(busy: Boolean) {
        b.login.isEnabled = !busy
        b.registerClient.isEnabled = !busy
        b.registerDriver.isEnabled = !busy
        b.continueOffline.isEnabled = !busy
        if (busy) b.status.text = "Traitement en cours…"
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
