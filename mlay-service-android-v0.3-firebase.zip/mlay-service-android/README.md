# M'lay Service — prototype Android hors ligne

Prototype original pour une application de livraison / transport à Toliara.

## Fonctions incluses
- Capture automatique des coordonnées GPS du demandeur.
- Enregistrement local de la dernière demande, sans serveur et sans Internet.
- Partage d'une course sous forme de texte par le menu Android : Bluetooth, SMS, WhatsApp, e-mail, etc.
- Ouverture directe de la destination dans Google Maps, ou dans une autre application cartographique compatible.
- Écran de carte centré sur Toliara avec osmdroid/OpenStreetMap.
- Base prévue pour importer une carte locale MBTiles et fonctionner sans connexion.
- Logo fourni intégré à l'application.

## Concept original : « Course-éclair »
Chaque demande devient une fiche compacte contenant un identifiant, le nom, le téléphone, le type de service, un repère et les coordonnées GPS. La fiche peut être transmise directement d'un téléphone à un autre, même sans données mobiles, via Bluetooth ou SMS.

## Ouvrir le projet
1. Installer Android Studio.
2. Ouvrir le dossier du projet.
3. Laisser Gradle synchroniser les dépendances.
4. Brancher un téléphone Android avec le débogage USB activé.
5. Cliquer sur **Run**.

## Carte de Toliara réellement hors ligne
La vue utilise osmdroid. Pour une carte 100 % hors ligne, produire un fichier de tuiles `toliara.mbtiles` depuis des données OpenStreetMap avec un outil compatible, puis le copier dans le stockage osmdroid de l'appareil. Vérifier les licences et l'attribution OpenStreetMap avant toute diffusion commerciale.

> Google Maps lui-même ne peut pas être embarqué comme une carte hors ligne privée dans l'application. La bonne architecture est : carte OpenStreetMap/MBTiles dans M'lay Service + redirection Google Maps lorsque le téléphone dispose de l'application et éventuellement d'Internet.

## Bluetooth
Le bouton de partage utilise le sélecteur Android. Si l'appareil propose Bluetooth, l'utilisateur peut transmettre la fiche au livreur. Cette approche est plus robuste qu'un protocole Bluetooth propriétaire pour un premier MVP. Une version suivante peut ajouter appairage, découverte et acceptation automatique des courses entre deux installations M'lay.

## Sécurité / production
Ce prototype est un MVP local. Avant publication : authentification, chiffrement, consentement GPS, suppression des données, historique des courses, profils client/livreur, tarification, validation téléphonique, tests terrain et politique de confidentialité.

## Version 0.2 — envoi adaptatif et synchronisation
Le bouton principal applique désormais cette stratégie :
1. **Internet disponible** : la demande est enregistrée dans une file locale et WorkManager tente son envoi vers l'API configurée. Toute demande restante est retentée lorsque Wi-Fi ou données mobiles reviennent.
2. **Pas d'Internet** : l'application tente un relais Bluetooth vers un appareil déjà appairé dont le nom commence par `MLAY-LIVREUR`.
3. **Bluetooth indisponible ou échec** : bascule automatique vers un SMS compact contenant les informations essentielles et les coordonnées GPS.

L'administrateur peut ouvrir **Paramètres admin / modèle SMS** et modifier :
- le modèle de SMS avec les variables `{id}`, `{service}`, `{lat}`, `{lon}`, `{phone}`, `{name}`, `{details}` ;
- l'adresse HTTPS du serveur de synchronisation.

### Important pour le Bluetooth
Le prototype utilise une connexion Bluetooth RFCOMM entre deux installations compatibles et recherche d'abord les téléphones livreurs déjà appairés. Une détection réelle du « plus proche » nécessite que l'application livreur diffuse le service M'lay et que les permissions Bluetooth soient accordées. La puissance du signal donne une proximité approximative, pas une distance GPS fiable.

### Important pour le SMS automatique
Android demande l'autorisation SMS à l'utilisateur. La distribution sur Google Play peut aussi imposer des restrictions supplémentaires sur l'usage de `SEND_SMS`. Pour une publication commerciale, prévoir soit une validation de politique, soit une ouverture de l'application SMS avec message prérempli.

### Serveur
Le projet contient le client de synchronisation, mais pas encore le serveur central ni la base de données. L'admin doit renseigner une API acceptant un tableau JSON en POST. Sans cette API, les demandes restent conservées localement et les relais Bluetooth/SMS continuent de fonctionner.

## Version 0.3 — Firebase intégré

Le code contient maintenant :
- Firebase Authentication par e-mail/mot de passe pour les comptes client et livreur ;
- profils `client`, `livreur` et rôle `admin` protégé ;
- synchronisation des demandes dans Cloud Firestore ;
- cache hors ligne Firestore et reprise automatique à la reconnexion ;
- enregistrement du modèle SMS administrateur dans `config/dispatch` ;
- Firebase Cloud Messaging avec stockage du jeton FCM ;
- dépendances Firebase Storage prêtes pour les photos et justificatifs ;
- règles Firestore et Storage fournies à la racine.

### Étape obligatoire : connecter votre propre projet Firebase

Les identifiants Firebase sont propres à votre compte et ne peuvent pas être générés dans ce ZIP. Dans Firebase Console :
1. Créez le projet `mlay-service`.
2. Ajoutez une application Android avec le package `com.mlay.service`.
3. Activez Authentication > E-mail/Mot de passe.
4. Créez Cloud Firestore et Storage.
5. Téléchargez `google-services.json` et placez-le dans `app/google-services.json`.
6. Publiez `firestore.rules` et `storage.rules` depuis la console ou Firebase CLI.
7. Créez d'abord un utilisateur normal, puis attribuez manuellement `role: admin` dans son document `users/{uid}`.

Sans `google-services.json`, le projet reste compilable en mode hors ligne et affiche un avertissement. Firebase s'active automatiquement dès que le vrai fichier est ajouté.
