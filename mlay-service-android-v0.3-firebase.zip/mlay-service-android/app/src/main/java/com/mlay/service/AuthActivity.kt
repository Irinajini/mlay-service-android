package com.mlay.service

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.mlay.service.databinding.ActivityAuthBinding

class AuthActivity : AppCompatActivity() {
    private lateinit var b: ActivityAuthBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAuthBinding.inflate(layoutInflater); setContentView(b.root)
        if (!FirebaseRepository.available(this)) b.status.text = "Ajoutez app/google-services.json pour activer Firebase."
        b.login.setOnClickListener { login() }
        b.registerClient.setOnClickListener { register("client") }
        b.registerDriver.setOnClickListener { register("livreur") }
        b.continueOffline.setOnClickListener { openMain() }
    }
    private fun login() {
        if (!FirebaseRepository.available(this)) return
        FirebaseAuth.getInstance().signInWithEmailAndPassword(b.email.text.toString().trim(), b.password.text.toString())
            .addOnSuccessListener { openMain() }.addOnFailureListener { b.status.text = it.message }
    }
    private fun register(role: String) {
        if (!FirebaseRepository.available(this)) return
        val email=b.email.text.toString().trim(); val pass=b.password.text.toString()
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).addOnSuccessListener { r ->
            val uid=r.user?.uid ?: return@addOnSuccessListener
            FirebaseFirestore.getInstance().collection("users").document(uid).set(mapOf("email" to email,"role" to role,"active" to true))
                .addOnSuccessListener { openMain() }.addOnFailureListener { b.status.text=it.message }
        }.addOnFailureListener { b.status.text=it.message }
    }
    private fun openMain(){ startActivity(Intent(this,MainActivity::class.java)); finish() }
}
