plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    if (file("google-services.json").exists()) id("com.google.gms.google-services")
}

android {
    namespace = "com.mlay.service"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mlay.service"
        minSdk = 24
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0-firebase"
    }
    buildFeatures { viewBinding = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("org.osmdroid:osmdroid-android:6.1.20")
    implementation(platform("com.google.firebase:firebase-bom:34.16.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-storage")
    implementation("com.google.firebase:firebase-messaging")
}
